#!/usr/bin/env python3
"""Jaspp: resilient LAN Mac remote + local Resend mail composer."""
import base64, ctypes, hashlib, json, math, os, re, secrets, socket, sqlite3, subprocess, threading, time
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('JASPP_DATA_DIR', Path.home() / 'Library/Application Support/Jaspp-Public'))
STATIC = ROOT / 'static'
LOCK = threading.RLock()
MAIL_TOKEN = secrets.token_urlsafe(32)
EMAIL = re.compile(r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+$")
MAX_BYTES = 10 * 1024 * 1024

class Problem(Exception):
    def __init__(self, message, status=400): self.message, self.status = message, status

def db():
    c = sqlite3.connect(DATA / 'mail.sqlite', timeout=30)
    c.row_factory = sqlite3.Row
    return c

def initialize():
    DATA.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(DATA, 0o700)
    with db() as c:
        c.execute('CREATE TABLE IF NOT EXISTS messages (request_id TEXT PRIMARY KEY, fingerprint TEXT, email_id TEXT, created REAL, payload TEXT, status TEXT, error TEXT)')
    os.chmod(DATA / 'mail.sqlite', 0o600)
    token_file = DATA / 'access-token'
    if not token_file.exists(): token_file.write_text(secrets.token_urlsafe(18))
    os.chmod(token_file, 0o600)
    return token_file.read_text().strip()

def get_key():
    try: return (DATA / 'api-key').read_text().strip()
    except FileNotFoundError: return ''

def mail_domain():
    try: return (DATA / 'mail-domain').read_text().strip()
    except FileNotFoundError: return ''

def mail_configured():
    return bool(get_key() and mail_domain())

def fan_command(command):
    """Talk only to the same-user native controller; never launch privileged code here."""
    path = f'/private/tmp/jaspp-fans-api-{os.getuid()}.sock'
    raw = json.dumps(command, separators=(',', ':')).encode() + b'\n'
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(3)
            client.connect(path)
            client.sendall(raw)
            response = bytearray()
            while b'\n' not in response and len(response) < 65536:
                chunk = client.recv(4096)
                if not chunk: break
                response.extend(chunk)
        if len(response) >= 65536: raise ValueError('response too large')
        value = json.loads(bytes(response).split(b'\n', 1)[0])
        if not isinstance(value, dict): raise ValueError('invalid response')
        return value
    except (OSError, ValueError, UnicodeError):
        raise Problem('风扇组件未连接，请在 Mac 上打开更新后的 Jaspp。', 503)

class Mac:
    def __init__(self):
        self.cg = ctypes.CDLL('/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics')
        self.ds = ctypes.CDLL('/System/Library/PrivateFrameworks/DisplayServices.framework/DisplayServices')
        self.cg.CGGetActiveDisplayList.argtypes = [ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32)]
        self.cg.CGDisplayIsBuiltin.argtypes = [ctypes.c_uint32]
        self.ds.DisplayServicesGetBrightness.argtypes = [ctypes.c_uint32, ctypes.POINTER(ctypes.c_float)]
        self.ds.DisplayServicesSetBrightness.argtypes = [ctypes.c_uint32, ctypes.c_float]
        self.ddc = ROOT / 'bin' / 'm1ddc'
        self.ddc_inventory = ({}, 0.0)
        self.ddc_values = {}
        self.ddc_wake_values = {}

    def _ddc_screens(self):
        cached, updated = self.ddc_inventory
        if cached and time.time() - updated < 60: return cached
        if not self.ddc.exists(): return {}
        try:
            r = subprocess.run([str(self.ddc),'display','list','detailed'],capture_output=True,text=True,timeout=12)
            if r.returncode: return cached
            found = {}
            for block in re.split(r'(?=\[\d+\] )',r.stdout):
                ident = re.search(r'Display ID:\s*(\d+)',block)
                name = re.search(r'Product name:\s*(.+)',block)
                if ident: found[int(ident.group(1))] = (name.group(1).strip() if name else '外接显示器')
            self.ddc_inventory = (found,time.time())
            return found
        except (subprocess.TimeoutExpired,OSError): return cached

    def _ddc_get(self, ident):
        old = self.ddc_values.get(ident)
        if old and time.time() - old[1] < 5: return old[0]
        try:
            r = subprocess.run([str(self.ddc),'display',f'id={ident}','get','luminance'],capture_output=True,text=True,timeout=8)
            if r.returncode: return old[0] if old else None
            value = int(r.stdout.strip().splitlines()[-1])
            if 0 <= value <= 100:
                self.ddc_values[ident] = (value,time.time()); return value
        except (subprocess.TimeoutExpired,OSError,ValueError,IndexError): pass
        return old[0] if old else None

    def displays(self):
        ids, count = (ctypes.c_uint32 * 32)(), ctypes.c_uint32()
        if self.cg.CGGetActiveDisplayList(32, ids, ctypes.byref(count)) != 0: raise RuntimeError('无法读取显示器。')
        result, external_index = [], 0
        ddc_screens = self._ddc_screens()
        for ident in ids[:count.value]:
            value = ctypes.c_float()
            builtin = bool(self.cg.CGDisplayIsBuiltin(ident))
            native = self.ds.DisplayServicesGetBrightness(ident, ctypes.byref(value)) == 0
            if not builtin: external_index += 1
            ddc_value = None if native or builtin else self._ddc_get(int(ident))
            supported = native or ddc_value is not None
            name = 'Mac 内置显示器' if builtin else ddc_screens.get(int(ident),f'外接显示器 {external_index}')
            result.append({'id':int(ident), 'name':name, 'supported':supported, 'brightness':round(value.value*100) if native else ddc_value, 'method':'native' if native else ('ddc' if ddc_value is not None else 'unsupported')})
        return result

    def brightness(self, ident, value):
        if type(ident) is not int or type(value) not in (float,int) or not math.isfinite(value) or not 0 <= value <= 100: raise ValueError('亮度必须在 0–100% 之间。')
        target = next((d for d in self.displays() if d['id'] == ident),None)
        if not target or not target['supported']: raise ValueError('这个屏幕不支持亮度控制。')
        if target['method'] == 'native':
            if self.ds.DisplayServicesSetBrightness(ident, value/100) != 0: raise RuntimeError('亮度调整失败。')
        elif target['method'] == 'ddc':
            try: r = subprocess.run([str(self.ddc),'display',f'id={ident}','set','luminance',str(round(value))],capture_output=True,text=True,timeout=10)
            except subprocess.TimeoutExpired: raise RuntimeError('外接显示器响应超时。')
            if r.returncode: raise RuntimeError('外接显示器拒绝了亮度指令。')
            self.ddc_values[ident] = (round(value),time.time())
        else: raise ValueError('这个屏幕不支持亮度控制。')

    def display_power(self, ident, action):
        if type(ident) is not int or action not in ('wake','off'): raise ValueError('未知显示器操作。')
        target = next((d for d in self.displays() if d['id'] == ident),None)
        if not target or target['method'] != 'ddc': raise ValueError('只能单独控制支持 DDC 的外接显示器。')
        if action == 'off' and type(target.get('brightness')) in (int,float) and target['brightness'] > 0:
            self.ddc_wake_values[ident] = round(target['brightness'])
        # MCCS VCP D6: 1 = on, 5 = hard off.
        value = '1' if action == 'wake' else '5'
        try:
            r = subprocess.run([str(self.ddc),'display',f'id={ident}','set','standby',value],capture_output=True,text=True,timeout=10)
        except subprocess.TimeoutExpired: raise RuntimeError('外接显示器响应超时。')
        if r.returncode: raise RuntimeError('外接显示器拒绝了电源指令。')
        if action == 'wake' and ident in self.ddc_wake_values:
            restore = self.ddc_wake_values[ident]
            for _ in range(3):
                time.sleep(0.7)
                try:
                    bright = subprocess.run([str(self.ddc),'display',f'id={ident}','set','luminance',str(restore)],capture_output=True,text=True,timeout=8)
                    if bright.returncode == 0:
                        self.ddc_values[ident] = (restore,time.time())
                        break
                except (subprocess.TimeoutExpired,OSError): pass
        return {'id':ident,'action':action,'message':'外接显示器已唤醒。' if action == 'wake' else '外接显示器已完全息屏。'}

    def volume(self, value=None):
        if value is not None and (type(value) not in (int,float) or not math.isfinite(value) or not 0 <= value <= 100): raise ValueError('音量必须在 0–100% 之间。')
        script = 'var a=Application.currentApplication();a.includeStandardAdditions=true;'
        if value is not None: script += 'a.setVolume(null,{outputVolume:%d,outputMuted:%s});' % (round(value), 'true' if value == 0 else 'false')
        script += 'JSON.stringify(a.getVolumeSettings());'
        r = subprocess.run(['/usr/bin/osascript','-l','JavaScript','-e',script], capture_output=True, text=True, timeout=12)
        if r.returncode: raise RuntimeError('无法调节当前音频设备的系统音量。')
        s = json.loads(r.stdout); return {'value':s['outputVolume'], 'muted':s['outputMuted']}

    def music(self, action=None):
        commands = {'toggle':'m.playpause();','play':'m.play();','pause':'m.pause();','next':'m.nextTrack();','previous':'m.previousTrack();'}
        if action is not None and action not in commands: raise ValueError('未知音乐操作。')
        script = """var m=Application('com.apple.Music'); function state(){if(!m.running())return {running:false,state:'stopped',name:'Apple Music 尚未打开',artist:''};var s={running:true,state:m.playerState(),name:'尚未选择歌曲',artist:''};try{s.name=m.currentTrack.name();s.artist=m.currentTrack.artist();s.album=m.currentTrack.album();}catch(e){}return s;}""" + (commands[action] if action else '') + '\nJSON.stringify(state());'
        r = subprocess.run(['/usr/bin/osascript','-l','JavaScript','-e',script], capture_output=True, text=True, timeout=15)
        if r.returncode: raise RuntimeError('无法控制 Apple Music，请允许 Jaspp 控制“音乐”。')
        return json.loads(r.stdout)

    def screen(self, action):
        if action == 'off': command = ['/usr/bin/pmset','displaysleepnow']
        elif action == 'lock': command = ['/System/Library/CoreServices/Menu Extras/User.menu/Contents/Resources/CGSession','-suspend']
        elif action == 'shutdown': command = ['/usr/bin/osascript','-e','tell application "System Events" to shut down']
        else: raise Problem('未知屏幕操作。')
        try:
            r = subprocess.run(command, capture_output=True, text=True, timeout=60 if action == 'shutdown' else 10)
        except subprocess.TimeoutExpired:
            raise Problem('关机请求未完成，请查看 Mac 上的系统提示。' if action == 'shutdown' else '屏幕操作超时。', 504)
        if r.returncode:
            if action == 'shutdown':
                if '-1743' in r.stderr:
                    raise Problem('请在 Mac 的系统设置 → 隐私与安全性 → 自动化中，允许 Jaspp 控制“System Events（系统事件）”。', 403)
                raise Problem('关机请求未完成，请查看 Mac 上的系统提示。', 409)
            raise Problem('屏幕操作失败。', 502)
        return {'action':action,'message':{'off':'已发送熄屏指令。','lock':'已发送锁屏指令。','shutdown':'已发送关机指令，请查看 Mac 上是否有未保存内容的提示。'}[action]}

def text_field(obj, name, limit, required=False):
    value = obj.get(name, '')
    if not isinstance(value,str) or len(value) > limit: raise Problem('字段内容过长或格式不正确：'+name)
    if required and not value.strip(): raise Problem({'to':'请填写收件人。','subject':'请填写邮件主题。','text':'请填写正文。'}.get(name,'请填写必填内容。'))
    return value

def validate_mail(obj):
    if not isinstance(obj,dict): raise Problem('邮件格式不正确。')
    prefix = obj.get('sender_prefix','no-reply')
    if not isinstance(prefix,str) or not re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9._+-]{0,62}[A-Za-z0-9])?',prefix) or '..' in prefix: raise Problem('发件前缀格式不正确。')
    domain = mail_domain()
    if not domain: raise Problem('请先在设置中填写你已验证的发件域名。')
    payload, total = {'from':prefix+'@'+domain}, 0
    for name in ('to','cc','bcc'):
        addresses = [s.strip() for s in re.split(r'[,;，；\n]',text_field(obj,name,4000,name=='to')) if s.strip()]
        if any(len(s)>254 or not EMAIL.fullmatch(s) for s in addresses): raise Problem('邮箱地址格式不正确。')
        addresses = list(dict.fromkeys(addresses)); total += len(addresses)
        if addresses: payload[name] = addresses
    if not payload.get('to') or total > 20: raise Problem('请填写收件人，每封邮件最多 20 个收件地址。')
    payload['subject'] = text_field(obj,'subject',200,True).strip()
    if '\r' in payload['subject'] or '\n' in payload['subject']: raise Problem('主题不能包含换行。')
    payload['text'] = text_field(obj,'text',200000,True)
    reply = text_field(obj,'reply_to',254).strip()
    if reply:
        if not EMAIL.fullmatch(reply): raise Problem('回复邮箱格式不正确。')
        payload['reply_to'] = reply
    files = obj.get('attachments',[])
    if not isinstance(files,list) or len(files)>10: raise Problem('最多添加 10 个附件。')
    attachments, size = [], 0
    for f in files:
        if not isinstance(f,dict): raise Problem('附件格式不正确。')
        filename = text_field(f,'filename',200,True)
        if any(ord(ch)<32 for ch in filename) or '/' in filename or '\\' in filename: raise Problem('附件文件名不正确。')
        try:
            content=f.get('content'); raw=base64.b64decode(content,validate=True) if isinstance(content,str) else (_ for _ in ()).throw(ValueError())
        except (ValueError,TypeError): raise Problem('附件内容损坏，请重新选择。')
        size += len(raw); attachments.append({'filename':filename,'content':content})
    if size > MAX_BYTES: raise Problem('附件总大小不能超过 10 MB。')
    if attachments: payload['attachments'] = attachments
    return payload

def resend(method,path,payload=None,idem=None):
    key=get_key()
    if not key: raise Problem('请先在设置中保存 Resend API 密钥。')
    config=['url = '+json.dumps('https://api.resend.com'+path),'request = '+json.dumps(method),'header = '+json.dumps('Authorization: Bearer '+key),'header = "Content-Type: application/json"']
    if idem: config.append('header = '+json.dumps('Idempotency-Key: jaspp-'+idem))
    if payload is not None: config.append('data-binary = '+json.dumps(json.dumps(payload,ensure_ascii=True)))
    try:
        r=subprocess.run(['/usr/bin/curl','--silent','--show-error','--connect-timeout','10','--max-time','40','--config','-','--write-out','\n%{http_code}'],input='\n'.join(config),capture_output=True,text=True,timeout=45)
        if r.returncode: raise Problem('网络连接失败。发送结果可能尚未确认。',502)
        body,status=r.stdout.rsplit('\n',1); data=json.loads(body); status=int(status)
    except (subprocess.TimeoutExpired,ValueError): raise Problem('服务响应异常，请保持原内容重试。',502)
    if status>=400: raise Problem({401:'密钥无效，请在设置中更新。',403:'发送权限不足，请检查密钥权限与域名验证。',429:'发送太频繁或额度已用完，请稍后重试。',422:'邮件内容未被接受。'}.get(status,'Resend 暂时无法处理邮件。'),502)
    return data

def history():
    with db() as c: rows=c.execute('SELECT request_id,email_id,created,payload,status,error FROM messages ORDER BY created DESC LIMIT 100').fetchall()
    return [dict(row,payload=json.loads(row['payload'])) for row in rows]

def send_mail(obj):
    payload=validate_mail(obj); rid=obj.get('request_id','')
    if not isinstance(rid,str) or not re.fullmatch(r'[a-zA-Z0-9-]{20,80}',rid): raise Problem('发送编号无效，请刷新页面。')
    fingerprint=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
    summary=dict(payload); summary['attachments']=[{'filename':a['filename'],'size':len(base64.b64decode(a['content']))} for a in payload.get('attachments',[])]
    with LOCK,db() as c:
        old=c.execute('SELECT * FROM messages WHERE request_id=?',(rid,)).fetchone()
        if old:
            if old['fingerprint']!=fingerprint: raise Problem('这次重试与原邮件内容不同。',409)
            if old['email_id']: return {'id':old['email_id'],'status':old['status'],'duplicate':True}
        else:
            c.execute('INSERT INTO messages VALUES (?,?,?,?,?,?,?)',(rid,fingerprint,None,time.time(),json.dumps(summary),'pending','')); c.commit()
        try:
            response=resend('POST','/emails',payload,rid); eid=response.get('id')
            if not isinstance(eid,str): raise Problem('发送结果未确认。',502)
            c.execute('UPDATE messages SET email_id=?,status=?,error=? WHERE request_id=?',(eid,'sent','',rid)); c.commit()
            return {'id':eid,'status':'sent'}
        except Problem as e:
            c.execute('UPDATE messages SET status=?,error=? WHERE request_id=?',('unconfirmed',e.message,rid)); c.commit(); raise

class Handler(BaseHTTPRequestHandler):
    server_version='Jaspp/1.0'
    def log_message(self,*args): pass
    def answer(self,obj,status=200,kind='application/json; charset=utf-8'):
        raw=obj if isinstance(obj,bytes) else json.dumps(obj,ensure_ascii=False).encode()
        try:
            self.send_response(status); self.send_header('Content-Type',kind); self.send_header('Content-Length',str(len(raw))); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','no-referrer'); self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"); self.end_headers(); self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError): pass
    def local(self): return self.client_address[0] in ('127.0.0.1','::1')
    def authorized(self): return secrets.compare_digest(self.headers.get('Authorization',''),'Bearer '+self.server.token)
    def body(self,limit):
        try: length=int(self.headers.get('Content-Length','0'))
        except ValueError: raise Problem('请求长度不正确。')
        if not 0<length<=limit or self.headers.get_content_type()!='application/json': raise Problem('请求格式不正确。')
        try: obj=json.loads(self.rfile.read(length))
        except (ValueError,UnicodeError): raise Problem('请求格式不正确。')
        if not isinstance(obj,dict): raise Problem('请求格式不正确。')
        return obj
    def do_GET(self):
        path=urlsplit(self.path).path
        try:
            if path in ('/','/remote'): return self.redirect('/remote/')
            if path=='/health': return self.answer({'ok':True,'started':self.server.started,'port':self.server.server_port})
            if path=='/app/state':
                if not self.local(): raise Problem('仅允许本机访问。',403)
                with LOCK:
                    data={'started':self.server.started,'port':self.server.server_port,'urls':self.server.urls,'token':self.server.token,'configured':mail_configured(),'domain':mail_domain(),'history':history()[:3],'music':None,'volume':None,'displays':[],'errors':{}}
                    for key,func in [('music',self.server.mac.music),('volume',self.server.mac.volume),('displays',self.server.mac.displays)]:
                        try:data[key]=func()
                        except Exception as e:data['errors'][key]=str(e)
                return self.answer(data)
            if path=='/remote/api/state':
                if not self.authorized(): raise Problem('请输入正确的连接口令。',401)
                with LOCK:
                    data={'host':socket.gethostname(),'music':None,'volume':None,'displays':[],'errors':{}}
                    for key,func in [('music',self.server.mac.music),('volume',self.server.mac.volume),('displays',self.server.mac.displays)]:
                        try:data[key]=func()
                        except Exception as e:data['errors'][key]=str(e)
                return self.answer(data)
            if path=='/remote/api/fans':
                if not self.authorized(): raise Problem('请输入正确的连接口令。',401)
                return self.answer(fan_command({'action':'state'}))
            if path=='/mail/api/state':
                if not self.local(): raise Problem('邮件功能仅允许本机访问。',403)
                return self.answer({'app':'jaspp-mail-v1','token':MAIL_TOKEN,'configured':mail_configured(),'domain':mail_domain(),'sender':'no-reply@'+(mail_domain() or 'example.com'),'history':history()})
            return self.static(path)
        except Problem as e: self.answer({'error':e.message},e.status)
        except Exception as e: self.answer({'error':'Jaspp 服务暂时异常：'+str(e)[:120]},500)
    def do_POST(self):
        path=urlsplit(self.path).path
        try:
            if path.startswith('/remote/api/'):
                if not self.authorized(): raise Problem('请输入正确的连接口令。',401)
                origin=self.headers.get('Origin'); expected='http://'+self.headers.get('Host','')
                if origin and origin!=expected: raise Problem('不允许跨站操作。',403)
                obj=self.body(2048)
                if path=='/remote/api/fans':
                    preset = obj.get('preset')
                    if preset not in ('system','off','rpm2400','rpm3000','rpm4000','rpm5000','full','temperature'):
                        raise Problem('未知风扇档位。')
                    return self.answer(fan_command({'action':'preset','preset':preset}))
                with LOCK:
                    if path=='/remote/api/music': result=self.server.mac.music(obj.get('action'))
                    elif path=='/remote/api/volume': result=self.server.mac.volume(obj.get('value'))
                    elif path=='/remote/api/brightness': self.server.mac.brightness(obj.get('id'),obj.get('value')); result=self.server.mac.displays()
                    elif path=='/remote/api/display-power': result=self.server.mac.display_power(obj.get('id'),obj.get('action'))
                    elif path=='/remote/api/screen': result=self.server.mac.screen(obj.get('action'))
                    else: raise Problem('接口不存在。',404)
                return self.answer({'ok':True,'result':result})
            if path.startswith('/mail/api/'):
                if not self.local(): raise Problem('邮件功能仅允许本机访问。',403)
                origin=self.headers.get('Origin')
                if origin not in (f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}') or not secrets.compare_digest(self.headers.get('X-Local-Token',''),MAIL_TOKEN): raise Problem('页面会话失效，请刷新重试。',403)
                obj=self.body(15*1024*1024)
                if path=='/mail/api/send': return self.answer(send_mail(obj))
                if path=='/mail/api/key':
                    key=obj.get('key','') or get_key()
                    domain=obj.get('domain','')
                    if not isinstance(domain,str): raise Problem('请输入发件域名。')
                    domain=domain.strip().lower()
                    if not isinstance(domain,str) or not re.fullmatch(r'(?=.{1,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.[a-z]{2,63}',domain) or '..' in domain: raise Problem('请输入你在 Resend 已验证的发件域名。')
                    if domain == 'example.com': raise Problem('请填写你自己的域名，示例域名不能用于发信。')
                    if not isinstance(key,str) or not re.fullmatch(r're_[A-Za-z0-9_-]{10,200}',key): raise Problem('请输入以 re_ 开头的 Resend API 密钥。')
                    fd=os.open(DATA/'api-key',os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
                    with os.fdopen(fd,'w') as f:f.write(key)
                    (DATA/'mail-domain').write_text(domain)
                    os.chmod(DATA/'mail-domain',0o600)
                    return self.answer({'ok':True})
                if path=='/mail/api/refresh':
                    eid=obj.get('id','')
                    with db() as c:
                        if not isinstance(eid,str) or not c.execute('SELECT 1 FROM messages WHERE email_id=?',(eid,)).fetchone(): raise Problem('找不到该邮件。',404)
                        state=resend('GET','/emails/'+eid).get('last_event','sent'); c.execute('UPDATE messages SET status=? WHERE email_id=?',(state,eid))
                    return self.answer({'status':state})
                raise Problem('接口不存在。',404)
            raise Problem('接口不存在。',404)
        except Problem as e:self.answer({'error':e.message},e.status)
        except Exception:self.answer({'error':'本机服务出现异常，操作没有完成。'},500)
    def redirect(self,target):
        self.send_response(302); self.send_header('Location',target); self.end_headers()
    def static(self,path):
        if path=='/mail': return self.redirect('/mail/')
        routes={'/remote/':('remote/index.html','text/html; charset=utf-8'),'/remote/app.js':('remote/app.js','text/javascript; charset=utf-8'),'/remote/style.css':('remote/style.css','text/css; charset=utf-8'),'/mail/':('mail/index.html','text/html; charset=utf-8'),'/mail/app.js':('mail/app.js','text/javascript; charset=utf-8'),'/mail/attachments.js':('mail/attachments.js','text/javascript; charset=utf-8'),'/mail/style.css':('mail/style.css','text/css; charset=utf-8')}
        if path not in routes: raise Problem('页面不存在。',404)
        if path.startswith('/mail/') and not self.local(): raise Problem('邮件功能仅允许本机访问。',403)
        name,kind=routes[path]; return self.answer((STATIC/name).read_bytes(),kind=kind)

class Server(ThreadingHTTPServer):
    daemon_threads=True; allow_reuse_address=True
    def get_request(self):
        sock,address=super().get_request(); sock.settimeout(30); return sock,address

def addresses(port):
    name=subprocess.run(['/usr/sbin/scutil','--get','LocalHostName'],capture_output=True,text=True).stdout.strip() or socket.gethostname().split('.')[0]
    urls=[f'http://{name}.local:{port}/remote/']
    for interface in ('en0','en1'):
        ip=subprocess.run(['/usr/sbin/ipconfig','getifaddr',interface],capture_output=True,text=True).stdout.strip()
        if ip: urls.append(f'http://{ip}:{port}/remote/')
    return list(dict.fromkeys(urls))

def main():
    os.umask(0o077); token=initialize(); preferred=int(os.environ.get('JASPP_PORT','8765')); server=None
    for port in range(preferred,preferred+20):
        try: server=Server(('0.0.0.0',port),Handler); break
        except OSError: continue
    if server is None: raise SystemExit('Jaspp 无法找到可用端口。')
    server.token,server.mac,server.started=token,Mac(),time.time(); server.urls=addresses(server.server_port)
    (DATA/'connection.json').write_text(json.dumps({'port':server.server_port,'urls':server.urls,'token':token},ensure_ascii=False))
    bonjour=subprocess.Popen(['/usr/bin/dns-sd','-R','Jaspp','_http._tcp','local',str(server.server_port)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    awake=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(os.getpid())],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    print('JASPP_READY '+str(server.server_port),flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close(); bonjour.terminate(); awake.terminate()

if __name__=='__main__': main()
