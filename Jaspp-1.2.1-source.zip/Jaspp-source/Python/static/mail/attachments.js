// Shared extraction for real paste and drop events. Prefer files over items to
// avoid adding the same clipboard image twice when the browser exposes both.
(function(root){
  function extract(transfer){
    if(!transfer)return [];
    const files=Array.from(transfer.files||[]);
    if(files.length)return files;
    return Array.from(transfer.items||[]).filter(item=>item.kind==='file').map(item=>item.getAsFile()).filter(Boolean);
  }
  function filename(file,index){
    const extension=({'image/png':'png','image/jpeg':'jpg','image/webp':'webp','image/gif':'gif'})[file.type]||'bin';
    const name=file.name||`粘贴附件-${Date.now()}-${index+1}.${extension}`;
    return name.replace(/[\x00-\x1f/\\]/g,'_').slice(0,200);
  }
  const exports={extract,filename};
  if(typeof module!=='undefined'&&module.exports)module.exports=exports;
  else root.JmailFiles=exports;
})(globalThis);
