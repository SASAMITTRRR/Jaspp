const $ = id => document.getElementById(id);
const fields = ['to','cc','bcc','reply_to','subject','text'];
const statuses = {sent:'已提交',delivered:'已投递',delivery_delayed:'投递延迟',bounced:'已退信',failed:'发送失败',complained:'被标记为垃圾邮件',opened:'已打开',clicked:'已点击',pending:'处理中',unconfirmed:'结果待确认',queued:'排队中'};
let mailDomain='example.com';
let token='', configured=false, files=[], busy=false, records=[], requestId=crypto.randomUUID(), lockedPayload=null;
const DRAFT='jaspp-mail-draft-v1';
function notice(message,error=false){$('notice').hidden=false;$('notice').textContent=message;$('notice').classList.toggle('error',error);}
function values(){return {...Object.fromEntries(fields.map(f=>[f,$(f).value])),sender_prefix:$('senderPrefix').value.trim()};}
function senderAddress(){return $('senderPrefix').value.trim()+'@'+mailDomain;}
function saveDraft(){try{localStorage.setItem('jmail-prefix',$('senderPrefix').value);localStorage.setItem(DRAFT,JSON.stringify({...values(),requestId,locked:!!lockedPayload,attachmentNames:files.map(f=>f.filename)}));$('draftStatus').textContent='草稿已保存';}catch{$('draftStatus').textContent='浏览器无法保存草稿，请勿关闭页面';}}
function restore(){try{$('senderPrefix').value=localStorage.getItem('jmail-prefix')||'no-reply';const d=JSON.parse(localStorage.getItem(DRAFT)||'null');if(!d)return;for(const f of fields)if(typeof d[f]==='string')$(f).value=d[f];if(typeof d.sender_prefix==='string')$('senderPrefix').value=d.sender_prefix;requestId=d.requestId||requestId;if(d.attachmentNames?.length)notice('草稿已恢复。请重新添加原附件：'+d.attachmentNames.join('、'),true);if(d.cc||d.bcc||d.reply_to){$('extraFields').hidden=false;$('moreBtn').setAttribute('aria-expanded','true');}}catch{notice('原草稿无法读取，可以重新写信。',true);}count();}
function count(){$('wordCount').textContent=$('text').value.length.toLocaleString()+' 字';$('draftCount').textContent=fields.some(f=>$(f).value.trim())||files.length?'1':'0';$('sidebarSender').textContent=senderAddress();$('profileBadge').title=senderAddress();}
function el(tag,txt,cls){const n=document.createElement(tag);if(txt!==undefined)n.textContent=txt;if(cls)n.className=cls;return n;}
async function api(path,data){const r=await fetch('/mail'+path,{method:'POST',headers:{'Content-Type':'application/json','X-Local-Token':token},body:JSON.stringify(data)});const v=await r.json();if(!r.ok)throw Error(v.error||'操作未完成，请稍后重试。');return v;}
async function load(){try{const r=await fetch('/mail/api/state');if(!r.ok)throw Error();const s=await r.json();token=s.token;configured=s.configured;mailDomain=s.domain||'example.com';$('mailDomain').value=s.domain||'';$('senderDomain').textContent='@'+mailDomain;count();records=s.history;$('connection').textContent=configured?'● 发信服务已配置':'○ 等待配置密钥';$('sendBtn').disabled=!configured||busy;$('keyStatus').textContent=configured?'已保存密钥，无需重复填写。':'尚未配置，请粘贴 Resend API 密钥。';$('historyCount').textContent=records.length;renderHistory();pollDelivery();}catch{$('connection').textContent='本机服务未连接';$('sendBtn').disabled=true;notice('本机服务未连接，请双击“启动写信台.command”后刷新页面。',true);}}
// Poll one pending message at a time; completed messages no longer consume requests.
const deliveryChecks=new Map();
let deliveryChecking=false;
function waitingForDelivery(r){return r.email_id&&['queued','sent','pending','delivery_delayed'].includes(r.status);}
async function pollDelivery(){
 if(deliveryChecking||busy||!configured||document.hidden)return;
 const pending=records.filter(waitingForDelivery).sort((a,b)=>(deliveryChecks.get(a.email_id)||0)-(deliveryChecks.get(b.email_id)||0));
 if(!pending.length){$('deliveryStatus').textContent='投递状态已更新';return;}
 deliveryChecking=true;
 const r=pending[0];deliveryChecks.set(r.email_id,Date.now());
 try{
  const result=await api('/api/refresh',{id:r.email_id});
  const current=records.find(item=>item.email_id===r.email_id);
  if(current)current.status=result.status;
  renderHistory();
  $('deliveryStatus').textContent=records.some(waitingForDelivery)?'正在自动跟踪投递状态…':'投递状态已更新';
 }catch{$('deliveryStatus').textContent='暂时无法查询投递状态，将自动重试';}
 finally{deliveryChecking=false;}
}
setInterval(pollDelivery,5000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)pollDelivery();});
function renderFiles(){$('files').replaceChildren();files.forEach((f,i)=>{const item=el('div',undefined,'file');if(f.type?.startsWith('image/')){const img=el('img');img.className='file-preview';img.src='data:'+f.type+';base64,'+f.content;img.alt=f.filename;item.append(img);}else item.append(el('span','▤','file-symbol'));const meta=el('div',undefined,'file-meta');const name=el('span',f.filename,'file-name');name.title=f.filename;meta.append(name,el('span',(f.size/1024).toFixed(1)+' KB','file-size'));item.append(meta);const remove=el('button','×');remove.type='button';remove.setAttribute('aria-label','移除附件 '+f.filename);remove.disabled=busy;remove.onclick=()=>{files.splice(i,1);renderFiles();saveDraft();};item.append(remove);$('files').append(item);});count();}
function showView(history){$('composeView').hidden=history;$('historyView').hidden=!history;$('composeNav').classList.toggle('active',!history);$('draftNav').classList.toggle('active',!history);$('historyNav').classList.toggle('active',history);if(history)load();}
function line(parent,label,value){const n=el('div',undefined,'review-line');n.append(el('b',label),el('span',value));parent.append(n);}
function renderHistory(){$('historyList').replaceChildren();const query=$('searchMail').value.toLowerCase().trim();const visible=records.filter(r=>!query||[r.payload.subject,r.payload.text,r.payload.from,...r.payload.to].join(' ').toLowerCase().includes(query));$('resultCount').textContent=visible.length+' 封';if(!visible.length){const n=el('div',undefined,'empty');n.append(el('b','↗'),el('div',query?'没有找到匹配的邮件。':'还没有寄出的邮件。写第一封吧。'));$('historyList').append(n);return;}visible.forEach(r=>{const card=el('article',undefined,'history-card'),info=el('div',undefined,'history-info'),actions=el('div',undefined,'history-actions');info.append(el('h3',r.payload.subject),el('p',r.payload.to.join('、')),el('small',new Date(r.created*1000).toLocaleString('zh-CN')));const badge=el('span',statuses[r.status]||r.status,'badge'+(['unconfirmed','failed','bounced','pending'].includes(r.status)?' warn':''));actions.append(badge);const detail=el('button','查看内容','text-btn');detail.onclick=()=>{$('detailTitle').textContent=r.payload.subject;const body=$('detailBody');body.replaceChildren();line(body,'发件人',r.payload.from);for(const [k,n] of [['to','收件人'],['cc','抄送'],['bcc','密送'],['reply_to','回复']])if(r.payload[k])line(body,n,Array.isArray(r.payload[k])?r.payload[k].join('、'):r.payload[k]);if(r.payload.attachments?.length)line(body,'附件',r.payload.attachments.map(a=>a.filename).join('、'));body.append(el('div',r.payload.text,'preview'));if(r.error)body.append(el('p',r.error,'hint'));$('detailDialog').showModal();};actions.append(detail);if(r.email_id){const refresh=el('button','查询投递 ↻','text-btn');refresh.onclick=async()=>{refresh.disabled=true;refresh.textContent='查询中…';try{const s=await api('/api/refresh',{id:r.email_id});r.status=s.status;renderHistory();}catch(e){refresh.textContent='查询失败，点此重试';refresh.title=e.message;refresh.disabled=false;}};actions.append(refresh);}card.append(info,actions);$('historyList').append(card);});}
function validateForm(){const v=values();if(!/^[A-Za-z0-9](?:[A-Za-z0-9._+-]{0,62}[A-Za-z0-9])?$/.test(v.sender_prefix)||v.sender_prefix.includes('..')){$('senderPrefix').focus();throw Error('发件前缀请使用 1–64 位字母、数字、点、短横线、下划线或加号，以字母或数字开头和结尾，不能连续两个点。');}const re=/^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+$/;let total=0;for(const f of ['to','cc','bcc']){const a=v[f].split(/[,;，；\n]/).map(x=>x.trim()).filter(Boolean);total+=a.length;if((f==='to'&&!a.length)||a.some(x=>!re.test(x))){if(f!=='to'){$('extraFields').hidden=false;$('moreBtn').setAttribute('aria-expanded','true');}$(f).focus();throw Error('请填写有效的邮箱地址；多个地址用逗号分隔。');}}if(total>20)throw Error('每封邮件最多 20 个收件地址。');if(!v.subject.trim()||!v.text.trim())throw Error('请填写主题和正文。');if(v.reply_to&&!re.test(v.reply_to.trim())){$('extraFields').hidden=false;$('moreBtn').setAttribute('aria-expanded','true');$('reply_to').focus();throw Error('回复邮箱格式不正确。');}return {...v,attachments:files.map(({filename,content})=>({filename,content}))};}
function setBusy(b){busy=b;for(const f of fields)$(f).disabled=b;for(const id of ['attachBtn','clearBtn','moreBtn','confirmSend','cancelSend','pasteBtn','senderPrefix'])$(id).disabled=b;$('sendBtn').disabled=b||!configured;$('confirmSend').textContent=b?'正在发送…':'确认发送';renderFiles();}
$('compose').onsubmit=e=>{e.preventDefault();if(busy)return;try{const payload=validateForm();if(lockedPayload&&JSON.stringify(payload)!==JSON.stringify(lockedPayload))throw Error('上一封邮件的结果尚未确认，请恢复原内容重试，或先在发送记录中核实。');const review=$('review');review.replaceChildren();line(review,'发件人',senderAddress());for(const [k,n]of[['to','收件人'],['cc','抄送'],['bcc','密送'],['reply_to','回复']])if(payload[k])line(review,n,payload[k]);line(review,'主题',payload.subject);line(review,'附件',files.length?files.map(f=>f.filename).join('、'):'无');review.append(el('div',payload.text,'preview'));$('confirmDialog').showModal();}catch(e){notice(e.message,true);}};
$('confirmSend').onclick=async()=>{if(busy)return;let payload;try{payload=validateForm();}catch(e){notice(e.message,true);return;}lockedPayload=payload;saveDraft();setBusy(true);try{const result=await api('/api/send',{...payload,request_id:requestId});$('confirmDialog').close();lockedPayload=null;for(const f of fields)$(f).value='';files=[];requestId=crypto.randomUUID();try{localStorage.removeItem(DRAFT);}catch{}count();$('draftStatus').textContent='已发送，可以开始下一封';notice('邮件已提交，投递状态会自动更新，可在“已发送”中查看。');await load();}catch(e){$('confirmDialog').close();notice(e.message+' 草稿已保留。请保持原内容重试。',true);}finally{setBusy(false);}};
$('cancelSend').onclick=()=>$('confirmDialog').close();$('confirmDialog').addEventListener('cancel',e=>{if(busy)e.preventDefault();});
$('moreBtn').onclick=()=>{$('extraFields').hidden=!$('extraFields').hidden;$('moreBtn').setAttribute('aria-expanded',String(!$('extraFields').hidden));};
$('attachBtn').onclick=()=>$('fileInput').click();
async function addFiles(incoming){
 if(!incoming.length)return;
 if(busy){notice('正在处理上一项操作，请稍后再添加附件。',true);return;}
 if(files.length+incoming.length>10||files.reduce((n,f)=>n+f.size,0)+incoming.reduce((n,f)=>n+f.size,0)>10*1024*1024){notice('最多 10 个附件，总大小不能超过 10 MB。',true);return;}
 setBusy(true);
 try{const added=await Promise.all(incoming.map((f,i)=>new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve({filename:JmailFiles.filename(f,i),size:f.size,type:f.type,content:String(reader.result).split(',')[1]});reader.onerror=()=>reject(Error('附件读取失败，请重新粘贴或拖入。'));reader.readAsDataURL(f);})));files.push(...added);saveDraft();notice('已添加 '+added.length+' 个附件。');}
 catch(e){notice(e.message,true);}finally{setBusy(false);}
}
$('fileInput').onchange=()=>{const incoming=[...$('fileInput').files];$('fileInput').value='';addFiles(incoming);};
document.addEventListener('paste',e=>{
 if($('composeView').hidden||document.querySelector('dialog[open]'))return;
 const incoming=JmailFiles.extract(e.clipboardData);
 if(incoming.length){e.preventDefault();addFiles(incoming);}
 else if(Array.from(e.clipboardData?.types||[]).some(t=>t==='text/uri-list'||t==='Files'))notice('浏览器没有提供这个文件的内容，请把文件直接拖进写信窗口；截图可以直接粘贴。',true);
});
$('pasteBtn').onclick=async()=>{
 if(busy)return;
 if(!navigator.clipboard?.read){$('text').focus();notice('请在正文中按 ⌘V 粘贴截图或图片；文件也可以直接拖入。');return;}
 try{const items=await navigator.clipboard.read();const incoming=[];for(const item of items){const type=item.types.find(t=>t.startsWith('image/'))||item.types.find(t=>!t.startsWith('text/'));if(type){const blob=await item.getType(type);incoming.push(new File([blob],JmailFiles.filename({type},incoming.length),{type}));}}
 if(incoming.length)await addFiles(incoming);else{$('text').focus();notice('剪贴板中没有可读取的附件。复制截图后按 ⌘V，或将文件拖进窗口。');}}
 catch{$('text').focus();notice('无法读取剪贴板。请在正文中按 ⌘V，或直接拖入文件。',true);}
};
let dragDepth=0;const drop=$('dropZone');
function hasFiles(e){return Array.from(e.dataTransfer?.types||[]).includes('Files');}
document.addEventListener('dragover',e=>{if(hasFiles(e))e.preventDefault();});
document.addEventListener('drop',e=>{if(hasFiles(e))e.preventDefault();});
drop.addEventListener('dragenter',e=>{if(hasFiles(e)){e.preventDefault();dragDepth++;drop.classList.add('drag-over');}});
drop.addEventListener('dragover',e=>{if(hasFiles(e)){e.preventDefault();e.dataTransfer.dropEffect='copy';}});
drop.addEventListener('dragleave',()=>{dragDepth=Math.max(0,dragDepth-1);if(!dragDepth)drop.classList.remove('drag-over');});
drop.addEventListener('drop',e=>{if(hasFiles(e)){e.preventDefault();dragDepth=0;drop.classList.remove('drag-over');addFiles(JmailFiles.extract(e.dataTransfer));}});
for(const f of fields)$(f).addEventListener('input',()=>{count();saveDraft();});
$('composeNav').onclick=()=>{showView(false);$('to').focus();};$('draftNav').onclick=()=>showView(false);$('searchMail').oninput=()=>{if($('searchMail').value.trim())showView(true);else renderHistory();};$('menuBtn').onclick=()=>{if(matchMedia('(max-width:700px)').matches){document.body.classList.toggle('mobile-menu');document.body.classList.remove('sidebar-closed');$('menuBtn').setAttribute('aria-expanded',String(document.body.classList.contains('mobile-menu')));}else{document.body.classList.toggle('sidebar-closed');$('menuBtn').setAttribute('aria-expanded',String(!document.body.classList.contains('sidebar-closed')));}};$('senderPrefix').oninput=()=>{count();saveDraft();};$('historyNav').onclick=()=>showView(true);$('reloadHistory').onclick=load;
$('settingsBtn').onclick=()=>{$('settingsError').textContent='';$('settingsDialog').showModal();};$('closeSettings').onclick=()=>{$('apiKey').value='';$('settingsDialog').close();};$('settingsDialog').addEventListener('close',()=>{$('apiKey').value='';});
$('saveKey').onclick=async()=>{$('saveKey').disabled=true;try{await api('/api/key',{key:$('apiKey').value.trim(),domain:$('mailDomain').value.trim()});$('apiKey').value='';$('settingsDialog').close();await load();notice('密钥已保存在本机。');}catch(e){$('settingsError').textContent=e.message;}finally{$('saveKey').disabled=false;}};
$('clearBtn').onclick=()=>{$('clearDialog').querySelector('p').textContent=lockedPayload?'上一封邮件结果尚未确认。清空后重新发送可能造成重复，请先在发送记录或 Resend 核实。':'正文和选中的附件都会移除。';$('clearDialog').showModal();};$('cancelClear').onclick=()=>$('clearDialog').close();$('doClear').onclick=()=>{for(const f of fields)$(f).value='';files=[];lockedPayload=null;requestId=crypto.randomUUID();try{localStorage.removeItem(DRAFT);}catch{}renderFiles();count();$('notice').hidden=true;$('draftStatus').textContent='草稿已清空';$('clearDialog').close();};$('closeDetail').onclick=()=>$('detailDialog').close();
restore();count();load();
