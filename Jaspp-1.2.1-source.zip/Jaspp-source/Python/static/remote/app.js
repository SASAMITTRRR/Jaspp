const $=s=>document.querySelector(s);let token=localStorage.getItem('macRemoteToken')||'',busy=false,polling=false,failures=0,revision=0;
const tell=text=>$('#message').textContent=text;
async function api(path,body){const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),body?.action==='shutdown'?65000:20000);try{const r=await fetch('/remote'+path,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+token,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined,signal:abort.signal});const data=await r.json();if(!r.ok){if(r.status===401)disconnect();throw Error(data.error||'请求失败');}return data;}finally{clearTimeout(timer);}}
function music(m){if(!m)return;$('#song').textContent=m.name;$('#artist').textContent=m.artist||'在 Mac 上选择喜欢的音乐';const playing=m.state==='playing';$('#playing').textContent=playing?'正在播放':m.state==='paused'?'已暂停':'未播放';$('#playIcon').toggleAttribute('hidden',playing);$('#pauseIcon').toggleAttribute('hidden',!playing);$('#playLabel').textContent=playing?'暂停':'播放';$('#toggle').setAttribute('aria-label',playing?'暂停':'播放');}
function displays(ds){const area=$('#displays');for(const existing of [...area.children])if(!ds.some(d=>String(d.id)===existing.dataset.id))existing.remove();for(const d of ds){let row=area.querySelector(`[data-id="${d.id}"]`);if(!row){row=document.createElement('div');row.dataset.id=d.id;const head=document.createElement('div');head.className='display-heading';const label=document.createElement('label');label.htmlFor='display-'+d.id;label.textContent=d.name;const value=document.createElement('output');head.append(label,value);row.append(head);if(d.supported){const slider=document.createElement('input');slider.id=label.htmlFor;slider.type='range';slider.min=0;slider.max=100;slider.step=1;slider.addEventListener('input',()=>{slider.dataset.editing='yes';value.textContent=slider.value+'%';});slider.addEventListener('change',async()=>{busy=true;revision++;slider.disabled=true;try{await api('/api/brightness',{id:d.id,value:Number(slider.value)});tell('');}catch(e){tell(e.message);}finally{delete slider.dataset.editing;slider.disabled=false;busy=false;refresh();}});row.append(slider);}else{const note=document.createElement('p');note.className='hint';note.textContent='此屏幕不支持系统亮度调节。';row.append(note);}if(d.method==='ddc'){const actions=document.createElement('div');actions.className='display-actions';for(const [action,title] of [['wake','唤醒外接屏'],['off','完全息屏']]){const button=document.createElement('button');button.textContent=title;button.addEventListener('click',async()=>{if(busy)return;busy=true;revision++;actions.querySelectorAll('button').forEach(x=>x.disabled=true);try{const data=await api('/api/display-power',{id:d.id,action});tell(data.result.message);}catch(e){tell(e.message);}finally{busy=false;actions.querySelectorAll('button').forEach(x=>x.disabled=false);}});actions.append(button);}row.append(actions);}area.append(row);}const slider=row.querySelector('input');if(!slider||(!slider.dataset.editing&&document.activeElement!==slider)){row.querySelector('output').textContent=d.supported?d.brightness+'%':'不支持';if(slider)slider.value=d.brightness;}}}
async function refresh(){if(!token||polling||busy||document.hidden)return;polling=true;const version=revision;try{const data=await api('/api/state');if(version!==revision||busy)return;failures=0;$('#pairing').hidden=true;$('#controls').hidden=false;$('#connection').textContent='● 已连接';$('#host').textContent=data.host+' · 本地连接';music(data.music);displays(data.displays);volume(data.volume);$('#volumeError').textContent=data.errors.volume||'';$('#musicError').textContent=data.errors.music||'';$('#displayError').textContent=data.errors.displays||(data.displays.length?'':'没有检测到可用屏幕。');document.querySelectorAll('[data-action]').forEach(b=>b.disabled=false);}catch(e){failures++;$('#connection').textContent='连接中断';document.querySelectorAll('[data-action]').forEach(b=>b.disabled=true);tell(e.name==='AbortError'?'连接超时，请查看 Mac 上的授权提示或网络。':e.message);}finally{polling=false;}}
function disconnect(){revision++;token='';localStorage.removeItem('macRemoteToken');$('#controls').hidden=true;$('#pairing').hidden=false;$('#connection').textContent='未连接';}
$('#pairForm').addEventListener('submit',async e=>{e.preventDefault();token=$('#token').value.trim();tell('');await refresh();if(token&&!failures){localStorage.setItem('macRemoteToken',token);$('#token').value='';}});
$('#disconnect').onclick=disconnect;
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',async()=>{if(busy)return;busy=true;revision++;document.querySelectorAll('[data-action]').forEach(x=>x.disabled=true);try{const data=await api('/api/music',{action:b.dataset.action});music(data.result);tell('');}catch(e){tell(e.message);}finally{busy=false;document.querySelectorAll('[data-action]').forEach(x=>x.disabled=false);refresh();}}));
function volume(v){const slider=$('#volumeSlider');slider.disabled=!v;if(!v)return;if(!slider.dataset.editing){slider.value=v.muted?0:v.value;$('#volumeValue').textContent=v.muted?'静音':v.value+'%';}}
$('#volumeSlider').addEventListener('input',()=>{const slider=$('#volumeSlider');slider.dataset.editing='yes';$('#volumeValue').textContent=slider.value==='0'?'静音':slider.value+'%';});
$('#volumeSlider').addEventListener('change',async()=>{const slider=$('#volumeSlider');busy=true;revision++;slider.disabled=true;try{const data=await api('/api/volume',{value:Number(slider.value)});delete slider.dataset.editing;volume(data.result);tell('');}catch(e){tell(e.message);}finally{delete slider.dataset.editing;slider.disabled=false;busy=false;refresh();}});
setInterval(refresh,1500);document.addEventListener('visibilitychange',refresh);refresh();

document.querySelectorAll('[data-screen]').forEach(button=>button.addEventListener('click',async()=>{
  if(busy)return;busy=true;revision++;button.disabled=true;
  const shuttingDown=button.dataset.screen==='shutdown';let accepted=false;
  if(shuttingDown){button.querySelector('span').textContent='正在请求关机…';tell('');}
  try{const data=await api('/api/screen',{action:button.dataset.screen});tell(data.result.message);accepted=true;}
  catch(e){tell(shuttingDown&&e instanceof TypeError?'连接已断开；Mac 可能正在关机，请查看 Mac。':e.message);}
  finally{
    busy=false;button.disabled=shuttingDown&&accepted;
    if(shuttingDown)button.querySelector('span').textContent=accepted?'关机指令已发送':'一键关机';
  }
}));

let fanBusy=false,fanPolling=false,fanRevision=0,fanHistory=[];
const fanColors=['#647e91','#92a590'];
document.querySelector('.tabbar').setAttribute('role','tablist');
document.querySelectorAll('[data-tab]').forEach(button=>{
  button.setAttribute('role','tab');button.id='tab-'+button.dataset.tab;
  button.onclick=()=>{
    document.querySelectorAll('[data-tab]').forEach(b=>{const active=b===button;b.classList.toggle('active',active);b.setAttribute('aria-selected',String(active));});
    document.querySelectorAll('[data-panel]').forEach(panel=>{panel.hidden=panel.dataset.panel!==button.dataset.tab;});
    if(button.dataset.tab==='fans')refreshFans();else refresh();
  };
});
document.querySelectorAll('[data-panel]').forEach(panel=>{panel.setAttribute('role','tabpanel');panel.setAttribute('aria-labelledby','tab-'+panel.dataset.panel);});
function renderFans(state){
  const temps=state.temperatures||{};
  const stopNote=document.querySelector('.off-support');
  if(stopNote)stopNote.textContent=(state.fans||[]).some(f=>f.minimum>0)?'硬件不支持':'';
  const autoButton=document.querySelector('[data-preset="system"]');
  if(autoButton)autoButton.textContent=state.preset==='system'?'系统自动 · 当前':'恢复系统自动';
  for(const [key,id] of [['cpu','cpuTemp'],['gpu','gpuTemp'],['battery','batteryTemp']])$('#'+id).textContent=Number.isFinite(temps[key])?Math.round(temps[key]):'—';
  document.querySelectorAll('[data-preset]').forEach(button=>{
    button.classList.toggle('selected',button.dataset.preset===state.preset);
    button.setAttribute('aria-pressed',String(button.dataset.preset===state.preset));
    button.disabled=!state.available||!!state.authorizing||fanBusy;
  });
  const area=$('#fanReadings'),fans=state.fans||[];
  for(const row of [...area.children])if(!fans.some(f=>String(f.id)===row.dataset.fan))row.remove();
  for(const fan of fans){
    let row=area.querySelector('[data-fan="'+fan.id+'"]');
    if(!row){row=document.createElement('article');row.className='glass fan-reading';row.dataset.fan=String(fan.id);const label=document.createElement('h2');label.textContent='风扇 '+(Number(fan.id)+1);const value=document.createElement('div');value.append(document.createElement('strong'));const unit=document.createElement('span');unit.textContent='RPM';value.append(unit);const target=document.createElement('p');target.className='target';row.append(label,value,target);area.append(row);}
    row.querySelector('strong').textContent=Number.isFinite(fan.rpm)?Math.round(fan.rpm):'—';
    const target=state.applied?.[String(fan.id)];
    row.querySelector('.target').textContent=Number.isFinite(target)?'目标 '+Math.round(target)+' RPM':'系统自动';
  }
  $('#fanStatus').textContent=state.status||'系统自动控制';
  $('#fanError').textContent=state.error||'';
  const now=Date.now();fanHistory.push({time:now,fans:fans.map(f=>({id:f.id,rpm:f.rpm}))});
  fanHistory=fanHistory.filter(x=>now-x.time<=120000);
  const lines=$('#fanLines');lines.replaceChildren();
  fans.forEach((fan,index)=>{
    const points=fanHistory.flatMap(sample=>{const value=sample.fans.find(f=>f.id===fan.id)?.rpm;if(!Number.isFinite(value))return [];const x=34+(sample.time-(now-120000))/120000*316;const y=96-Math.max(0,Math.min(7000,value))/7000*84;return [x.toFixed(1)+','+y.toFixed(1)];});
    if(points.length>1){const line=document.createElementNS('http://www.w3.org/2000/svg','polyline');line.setAttribute('points',points.join(' '));line.setAttribute('stroke',fanColors[index%fanColors.length]);lines.append(line);}
  });
}
async function refreshFans(){
  if(!token||fanPolling||fanBusy||document.hidden)return;
  fanPolling=true;const version=fanRevision;
  try{const state=await api('/api/fans');if(version===fanRevision&&!fanBusy)renderFans(state);}
  catch(e){$('#fanError').textContent=e.message;document.querySelectorAll('[data-preset]').forEach(b=>b.disabled=true);}
  finally{fanPolling=false;}
}
document.querySelectorAll('[data-preset]').forEach(button=>button.onclick=async()=>{
  if(fanBusy)return;fanBusy=true;fanRevision++;
  document.querySelectorAll('[data-preset]').forEach(b=>b.disabled=true);
  try{
    const result=await api('/api/fans',{preset:button.dataset.preset});
    if(result.state)renderFans(result.state);
    if(result.blocked){$('#heatWarningText').textContent=result.message;$('#heatWarning').showModal();}
    else if(!result.ok)throw Error(result.error||'风扇指令未完成');
    else $('#fanError').textContent='';
  }catch(e){$('#fanError').textContent=e.message;}
  finally{fanBusy=false;refreshFans();}
});
setInterval(refreshFans,700);document.addEventListener('visibilitychange',refreshFans);refreshFans();
