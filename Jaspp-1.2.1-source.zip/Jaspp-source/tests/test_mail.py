import importlib.util, tempfile, pathlib, os, ast, re
p=pathlib.Path(__file__).resolve().parents[1]/'Python/server.py'
ast.parse(p.read_text())
s=importlib.util.spec_from_file_location('jaspp_server',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
with tempfile.TemporaryDirectory(prefix='jaspp-release-test-') as d:
 m.DATA=pathlib.Path(d)
 a=m.initialize(); assert a and len(a)>16
 assert m.initialize()==a
 assert not m.mail_configured()
 message={'to':'recipient@example.org','subject':'test','text':'test'}
 try: m.validate_mail(message)
 except m.Problem: pass
 else: raise AssertionError('Unconfigured domain accepted')
 (m.DATA/'mail-domain').write_text('mail.example.org')
 assert m.validate_mail(message)['from']=='no-reply@mail.example.org'
 (m.DATA/'api-key').write_text('re_example_not_real_12345')
 assert m.mail_configured()
 assert m.history()==[]
 assert os.stat(m.DATA/'access-token').st_mode & 0o777==0o600
 print('PASS: clean profile, random token, persisted token, domain requirement, sender domain, configuration state, empty mail history, token permissions')


class FakeHandler:
 path='/mail/api/key'
 server=type('S',(),{'server_port':8765})()
 headers={'Origin':'http://127.0.0.1:8765','X-Local-Token':m.MAIL_TOKEN}
 def local(self):return True
 def body(self,limit):return self.payload
 def answer(self,obj,status=200):self.result=(obj,status);return self.result
with tempfile.TemporaryDirectory(prefix='jaspp-settings-test-') as d:
 m.DATA=pathlib.Path(d);m.initialize();h=FakeHandler()
 for domain in [None,42,{},'example.com','bad..domain.org']:
  h.payload={'key':'re_fake_key_for_testing_only','domain':domain};m.Handler.do_POST(h);assert h.result[1]==400,h.result
 h.payload={'key':'re_fake_key_for_testing_only','domain':'Mail.Example.Org'};m.Handler.do_POST(h);assert h.result[1]==200,h.result
 assert m.mail_domain()=='mail.example.org'
 h.payload={'key':'','domain':'sender.example.org'};m.Handler.do_POST(h);assert h.result[1]==200
 assert m.mail_domain()=='sender.example.org'
 print('PASS: settings validation, domain normalization, saved API key reuse; no network, mail or hardware operations')
