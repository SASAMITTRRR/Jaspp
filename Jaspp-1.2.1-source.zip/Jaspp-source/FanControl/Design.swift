import SwiftUI
import Charts
import AppKit

extension View {
    @ViewBuilder func jasppGlass(radius: CGFloat = 24, tint: Color? = nil, interactive: Bool = false) -> some View {
        if #available(macOS 26.0, *) {
            self.glassEffect(.regular.tint(tint).interactive(interactive), in: RoundedRectangle(cornerRadius: radius, style: .continuous))
        } else {
            self.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
        }
    }
    @ViewBuilder func jasppButton() -> some View {
        if #available(macOS 26.0, *) { self.buttonStyle(.glass) }
        else { self.buttonStyle(.bordered) }
    }
}

struct JasppBackdrop: View {
    var body: some View {
        ZStack {
            Color(red: 0.91, green: 0.88, blue: 0.83)
            RadialGradient(colors: [.white.opacity(0.95), .clear], center: .topLeading, startRadius: 0, endRadius: 650)
            RadialGradient(colors: [Color(red: 0.76, green: 0.66, blue: 0.53).opacity(0.20), .clear], center: .bottomTrailing, startRadius: 10, endRadius: 650)
        }.ignoresSafeArea()
    }
}

struct TemperatureTile: View {
    let title: String
    let value: Double?
    let color: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.system(size: 15, weight: .medium)).foregroundStyle(.secondary)
            HStack(alignment: .firstTextBaseline, spacing: 2) {
                Text(value.map { String(format: "%.0f", $0) } ?? "—")
                    .font(.system(size: 66, weight: .semibold, design: .rounded)).tracking(-2.8).monospacedDigit()
                    .contentTransition(.numericText())
                Text("°").font(.system(size: 37, weight: .medium, design: .rounded)).foregroundStyle(.secondary)
                Spacer(minLength: 0)
                Image(systemName: "thermometer.medium").font(.system(size: 23, weight: .light)).foregroundStyle(color)
            }
        }.padding(.horizontal, 22).padding(.vertical, 18).frame(maxWidth: .infinity, alignment: .leading)
            .jasppGlass(radius: 25, tint: color.opacity(0.035))
            .accessibilityElement(children: .combine)
    }
}

struct FansDashboardView: View {
    @ObservedObject var model: FanModel
    var embedded = false
    @State var showSensors = false
    var cpu: Double? { model.sensors.first(where: { $0.id == "TCMz" })?.temperature ?? model.chipTemperature }
    var gpu: Double? { model.sensors.filter { $0.id.hasPrefix("Tg") || $0.id.hasPrefix("TG") }.map(\.temperature).max() }
    var battery: Double? { model.sensors.first(where: { $0.id == "TB0T" })?.temperature ?? model.sensors.first(where: { $0.id.hasPrefix("TB") })?.temperature }

    var body: some View {
        ZStack {
            JasppBackdrop()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack(spacing: 10) {
                        Text(embedded ? "风扇" : "Jaspp Fans Control").font(.system(size: 22, weight: .semibold))
                        Spacer()
                        HStack(spacing: 6) {
                            Circle().fill(model.fans.isEmpty ? Color.gray : Color.green).frame(width: 7, height: 7)
                            Text(model.fans.isEmpty ? "未连接" : "已连接").font(.system(size: 12)).foregroundStyle(.secondary)
                        }
                        Button { showSensors = true } label: { Image(systemName: "thermometer.medium").frame(width: 24, height: 25) }.jasppButton().help("全部传感器")
                        Button { model.settings = true } label: { Image(systemName: "gearshape").frame(width: 24, height: 25) }.jasppButton().help("温控设置")
                    }.padding(.bottom, 2)
                    HStack(spacing: 14) {
                        TemperatureTile(title: "CPU 热点", value: cpu, color: .orange)
                        TemperatureTile(title: "GPU 热点", value: gpu, color: .orange.opacity(0.7))
                        TemperatureTile(title: "电池", value: battery, color: .blue)
                    }
                    presetPanel
                    if let error = model.error {
                        Label(error, systemImage: "exclamationmark.triangle").font(.system(size: 12)).foregroundStyle(.orange).textSelection(.enabled)
                    }
                    HStack(spacing: 14) {
                        ForEach(model.fans) { fan in
                            FanCard(fan: fan, target: model.applied[String(fan.id)], preset: model.controlActive ? model.confirmedPreset : .system)
                        }
                        if model.fans.isEmpty { Text("正在读取风扇…").font(.title3).frame(maxWidth: .infinity).padding(40).jasppGlass() }
                    }
                    chart
                    HStack {
                        if model.authorizing { ProgressView().controlSize(.small) }
                        Text(model.statusText).font(.system(size: 12)).foregroundStyle(.secondary)
                        Spacer()
                        Button("导出诊断") { model.exportDiagnostics() }.buttonStyle(.link).font(.system(size: 12))
                    }.padding(.horizontal, 5)
                }.padding(24)
            }.scrollIndicators(.hidden)
        }
        .frame(minWidth: embedded ? 700 : 850, minHeight: 650)
        .preferredColorScheme(.light)
        .sheet(isPresented: $model.settings) { CurveSettings(model: model) }
        .sheet(isPresented: $showSensors) { sensorSheet }
    }

    var presetPanel: some View {
        VStack(spacing: 12) {
            HStack(spacing: 9) {
                ForEach(Preset.allCases.filter { $0 != .system }) { p in
                    Button { model.choose(p) } label: {
                        VStack(spacing: 3) {
                            if let rpm = Int(p.title.replacingOccurrences(of: " RPM", with: "")) {
                                Text("\(rpm)").font(.system(size: 21, weight: .semibold, design: .rounded)).monospacedDigit()
                                Text("RPM").font(.system(size: 11, weight: .medium))
                            } else {
                                Text(p.title).font(.system(size: 14, weight: .semibold)).lineLimit(1).minimumScaleFactor(0.8)
                                if p == .off && model.fans.contains(where: { $0.minimum > 0 }) {
                                    Text("硬件不支持").font(.system(size: 9)).foregroundStyle(.secondary)
                                }
                            }
                        }
                        .frame(maxWidth: .infinity).frame(height: 64)
                        .foregroundStyle(model.preset == p ? Color.white : Color.primary)
                        .background(model.preset == p ? Color.blue.opacity(0.8) : Color.clear, in: RoundedRectangle(cornerRadius: 23))
                        .jasppGlass(radius: 23, tint: model.preset == p ? .blue : nil, interactive: true)
                        .overlay(RoundedRectangle(cornerRadius: 23).strokeBorder(.white.opacity(model.preset == p ? 0.95 : 0.25), lineWidth: model.preset == p ? 1.5 : 0.5))
                        .overlay(alignment: .topTrailing) {
                            if model.preset == p { Image(systemName: "checkmark.circle.fill").font(.system(size: 12, weight: .bold)).foregroundStyle(.white).padding(7) }
                        }
                        .shadow(color: model.preset == p ? .blue.opacity(0.25) : .clear, radius: 10, y: 4)
                    }.buttonStyle(.plain).disabled(model.authorizing || model.fans.isEmpty)
                        .accessibilityLabel(p.title).accessibilityAddTraits(model.preset == p ? .isSelected : [])
                }
            }
            Button { model.choose(.system) } label: {
                Label(model.preset == .system ? "系统自动 · 当前" : "恢复系统自动", systemImage: model.preset == .system ? "checkmark.circle.fill" : "arrow.trianglehead.2.clockwise.rotate.90")
                    .font(.system(size: 14, weight: .medium)).frame(maxWidth: .infinity).frame(height: 40)
                    .foregroundStyle(model.preset == .system ? Color.white : Color.primary)
                    .background(model.preset == .system ? Color.blue.opacity(0.8) : .clear, in: RoundedRectangle(cornerRadius: 24))
                    .jasppGlass(radius: 24, tint: model.preset == .system ? .blue : nil, interactive: true)
                    .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(.white.opacity(model.preset == .system ? 0.95 : 0.25), lineWidth: 1))
                    .shadow(color: model.preset == .system ? .blue.opacity(0.25) : .clear, radius: 10, y: 4)
            }.buttonStyle(.plain).disabled(model.authorizing)
                .accessibilityAddTraits(model.preset == .system ? .isSelected : [])
        }
    }

    var chart: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("转速趋势").font(.system(size: 14, weight: .semibold))
                Spacer()
                ForEach(Array(model.fans.enumerated()), id: \.element.id) { index, fan in
                    HStack(spacing: 5) { Circle().fill(index == 0 ? Color.blue : Color.teal).frame(width: 6, height: 6); Text(fan.name) }.font(.system(size: 11)).foregroundStyle(.secondary)
                }
            }
            Chart(model.history) { r in
                LineMark(x: .value("时间", r.time), y: .value("RPM", r.rpm)).lineStyle(StrokeStyle(lineWidth: 2))
                    .foregroundStyle(by: .value("风扇", r.fan)).interpolationMethod(.linear)
            }
            .chartForegroundStyleScale(range: [Color.blue, Color.teal])
            .chartLegend(.hidden)
            .chartYScale(domain: 0...max(7000, model.fans.map(\.maximum).max() ?? 7000))
            .chartXScale(domain: (model.lastUpdate ?? Date()).addingTimeInterval(-120)...(model.lastUpdate ?? Date()))
            .chartXAxis { AxisMarks(values: .automatic(desiredCount: 4)) { _ in AxisGridLine().foregroundStyle(.primary.opacity(0.05)); AxisValueLabel(format: .dateTime.hour().minute().second()).font(.system(size: 10)) } }
            .chartYAxis { AxisMarks(position: .leading, values: [0,2000,4000,6000]) { _ in AxisGridLine().foregroundStyle(.primary.opacity(0.05)); AxisValueLabel().font(.system(size: 10)) } }
            .frame(height: 133)
        }.padding(20).jasppGlass(radius: 24)
    }
    var sensorSheet: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack { Text("全部传感器").font(.title2.bold()); Spacer(); Button("完成") { showSensors = false }.keyboardShortcut(.cancelAction) }
            TextField("搜索名称或 SMC 编号", text: $model.search).textFieldStyle(.roundedBorder)
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(model.filteredSensors) { s in
                        HStack { Text(s.name); Spacer(); Text(String(format: "%.1f°C", s.temperature)).monospacedDigit() }.padding(.vertical, 9)
                        Divider()
                    }
                }
            }
        }.padding(24).frame(width: 440, height: 580)
    }
}

struct FanCard: View {
    let fan: Fan
    var target: Double?
    var preset: Preset
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack { Text(fan.name).font(.system(size: 13, weight: .medium)).foregroundStyle(.secondary); Spacer(); Image(systemName: "fan.fill").font(.system(size: 16, weight: .light)).foregroundStyle(.secondary.opacity(0.5)) }
            HStack(alignment: .firstTextBaseline, spacing: 5) {
                Text(String(format: "%.0f", fan.rpm)).font(.system(size: 43, weight: .semibold, design: .rounded)).tracking(-1.4).monospacedDigit().contentTransition(.numericText())
                Text("RPM").font(.system(size: 16, weight: .semibold)).foregroundStyle(.secondary)
            }
            Text(target.map { "目标 \(Int($0)) RPM" } ?? "系统自动").font(.system(size: 11)).foregroundStyle(.secondary)
        }.padding(.horizontal, 22).padding(.vertical, 17).frame(maxWidth: .infinity, alignment: .leading).jasppGlass(radius: 24)
    }
}
