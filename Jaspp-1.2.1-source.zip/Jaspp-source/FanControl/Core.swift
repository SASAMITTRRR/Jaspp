import Foundation

struct Fan: Identifiable, Codable {
    let id: Int
    var rpm: Double
    var minimum: Double
    var maximum: Double
    var target: Double?
    var mode: Double?
    var rangeValid: Bool { minimum.isFinite && maximum.isFinite && minimum >= 0 && maximum > minimum && maximum <= 20000 }
    var name: String { "风扇 \(id + 1)" }
}
struct Sensor: Identifiable, Codable {
    var id: String
    var temperature: Double
    var isChip: Bool { ["Tp", "Tc", "TC", "Tg", "TG", "Te", "Tf", "Ts"].contains { id.hasPrefix($0) } }
    var name: String {
        if id.hasPrefix("TB") || id.hasPrefix("Tb") { return "电池 · \(id)" }
        if id.hasPrefix("TG") || id.hasPrefix("Tg") { return "GPU 区域 · \(id)" }
        if id.hasPrefix("TC") || id.hasPrefix("Tc") || id.hasPrefix("Tp") || id.hasPrefix("Te") { return "芯片区域 · \(id)" }
        return "温度传感器 · \(id)"
    }
}
enum Preset: String, CaseIterable, Codable, Identifiable {
    case system, off, rpm2400, rpm3000, rpm4000, rpm5000, full, temperature
    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "系统自动"
        case .off: return "停转"
        case .rpm2400: return "2400 RPM"
        case .rpm3000: return "3000 RPM"
        case .rpm4000: return "4000 RPM"
        case .rpm5000: return "5000 RPM"
        case .full: return "满速"
        case .temperature: return "按温度调节"
        }
    }
    var symbol: String {
        switch self {
        case .system: return "apple.logo"
        case .full: return "wind"
        case .temperature: return "thermometer.medium"
        default: return "fan"
        }
    }
    func target(temperature: Double?, fan: Fan, curve: FanCurve) -> Double? {
        guard self != .system, fan.rangeValid else { return nil }
        let rpm: Double
        switch self {
        case .off: return fan.minimum == 0 ? 0 : nil
        case .rpm2400: rpm = 2400
        case .rpm3000: rpm = 3000
        case .rpm4000: rpm = 4000
        case .rpm5000: rpm = 5000
        case .full: rpm = fan.maximum
        case .temperature:
            guard let t = temperature, t.isFinite else { return nil }
            rpm = curve.rpm(at: t, maximum: fan.maximum)
        case .system: return nil
        }
        return min(fan.maximum, max(fan.minimum, rpm))
    }
}
struct FanCurve: Codable, Equatable {
    var thresholds: [Double] = [45, 55, 65, 75, 85]
    var valid: Bool {
        thresholds.count == 5 && thresholds.allSatisfy { $0.isFinite && (25...100).contains($0) }
        && zip(thresholds, thresholds.dropFirst()).allSatisfy { $1 - $0 >= 3 }
    }
    func rpm(at t: Double, maximum: Double) -> Double {
        let xs = valid ? thresholds : FanCurve().thresholds
        let ys = [2400.0, 3000, 4000, 5000, maximum].map { min($0, maximum) }
        if t <= xs[0] { return ys[0] }
        for i in 1..<xs.count where t < xs[i] {
            let f = (t - xs[i-1]) / (xs[i] - xs[i-1])
            return ys[i-1] + f * (ys[i] - ys[i-1])
        }
        return maximum
    }
}
final class Hardware {
    private var keys: [String] = []
    func read(_ key: String) -> Double? {
        var n = 0.0
        guard key.withCString({ jf_read($0, &n) }) == 0, n.isFinite else { return nil }
        return n
    }
    func write(_ key: String, _ n: Double) -> Bool { key.withCString { jf_write($0, n) } == 0 }
    func modeKey(_ id: Int) -> String { read("F\(id)md") != nil ? "F\(id)md" : "F\(id)Md" }
    func fans() -> [Fan] {
        guard let n = read("FNum"), (0...10).contains(n) else { return [] }
        return (0..<Int(n)).compactMap { id in
            guard let rpm = read("F\(id)Ac"), let lo = read("F\(id)Mn"), let hi = read("F\(id)Mx") else { return nil }
            return Fan(id: id, rpm: rpm, minimum: lo, maximum: hi, target: read("F\(id)Tg"), mode: read(modeKey(id)))
        }
    }
    func discover() {
        guard let n = read("#KEY"), n > 0, n <= 30000 else { return }
        var found: [String] = []
        for i in 0..<Int(n) {
            var buffer = [CChar](repeating: 0, count: 5)
            if jf_key(Int32(i), &buffer) == 0 {
                let key = String(cString: buffer)
                if key.hasPrefix("T"), let t = read(key), (5...130).contains(t) { found.append(key) }
            }
        }
        keys = Array(Set(found)).sorted()
    }
    func sensors() -> [Sensor] {
        keys.compactMap { key in
            guard let t = read(key), (5...130).contains(t) else { return nil }
            return Sensor(id: key, temperature: t)
        }
    }
    var error: String { String(cString: jf_error()) }
}
struct ControlRequest: Codable {
    var token: String
    var timestamp: Double
    var preset: Preset
    var curve: FanCurve
    var sensor: String // "chip-max" or an exact discovered key
    func valid(for expected: String, now: Double) -> Bool {
        token == expected && timestamp.isFinite && abs(now - timestamp) < 8 && curve.valid
    }
}
struct HelperStatus: Codable {
    var timestamp: Double
    var running: Bool
    var preset: Preset
    var error: String?
    var applied: [String: Double]
}

// A warning gates one explicit lowering action per hot episode. It does not
// rewrite targets, smooth transitions or repeatedly force maximum speed.
struct HotLoweringGuard {
    private(set) var warned = false
    private var coolSince: Double?
    mutating func observe(temperature: Double?, critical: Bool, now: Double) {
        if !critical, let temperature, temperature < 90 {
            if coolSince == nil { coolSince = now }
            if now - (coolSince ?? now) >= 10 { warned = false }
        } else { coolSince = nil }
    }
    mutating func block(temperature: Double?, critical: Bool, lowering: Bool, now: Double) -> Bool {
        observe(temperature: temperature, critical: critical, now: now)
        guard lowering, !warned, critical || (temperature ?? 0) >= 100 else { return false }
        warned = true
        return true
    }
}
