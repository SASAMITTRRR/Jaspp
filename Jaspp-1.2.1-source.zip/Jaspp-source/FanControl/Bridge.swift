import Foundation
import Darwin

final class FanOwnership {
    static let shared = FanOwnership()
    let owns: Bool
    private let fd: Int32
    private init() {
        fd = Darwin.open("/private/tmp/jaspp-fans-instance-\(getuid()).lock", O_RDWR | O_CREAT | O_NOFOLLOW, 0o600)
        var st = stat()
        owns = fd >= 0 && fstat(fd, &st) == 0 && st.st_uid == getuid() && (st.st_mode & S_IFMT) == S_IFREG && flock(fd, LOCK_EX | LOCK_NB) == 0
    }
    deinit { if fd >= 0 { Darwin.close(fd) } }
}

// Local-only IPC. Jaspp's existing authenticated HTTP service is the only LAN
// surface; this socket itself accepts requests solely from this macOS user.
final class FanBridge {
    static var path: String { "/private/tmp/jaspp-fans-api-\(getuid()).sock" }
    private let socketFD: Int32
    init?(handler: @escaping @MainActor ([String: Any]) -> [String: Any]) {
        guard FanOwnership.shared.owns else { return nil }
        let path = Self.path
        var st = stat()
        if lstat(path, &st) == 0 {
            guard st.st_uid == getuid(), (st.st_mode & S_IFMT) == S_IFSOCK else { return nil }
            unlink(path)
        }
        let fd = socket(AF_UNIX, SOCK_STREAM, 0)
        guard fd >= 0 else { return nil }
        var addr = sockaddr_un(); addr.sun_family = sa_family_t(AF_UNIX)
        let bytes = Array(path.utf8CString)
        guard bytes.count <= MemoryLayout.size(ofValue: addr.sun_path) else { Darwin.close(fd); return nil }
        withUnsafeMutableBytes(of: &addr.sun_path) { dst in bytes.withUnsafeBytes { src in dst.copyMemory(from: src) } }
        addr.sun_len = UInt8(MemoryLayout<sockaddr_un>.size)
        let bound = withUnsafePointer(to: &addr) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { Darwin.bind(fd, $0, socklen_t(MemoryLayout<sockaddr_un>.size)) } }
        guard bound == 0, chmod(path, 0o600) == 0, listen(fd, 8) == 0 else { Darwin.close(fd); unlink(path); return nil }
        socketFD = fd
        DispatchQueue.global(qos: .utility).async {
            while true {
                let client = accept(fd, nil, nil)
                if client < 0 { break }
                var peer: uid_t = 0; var group: gid_t = 0
                guard getpeereid(client, &peer, &group) == 0, peer == getuid() else { Darwin.close(client); continue }
                var noPipe: Int32 = 1; var timeout = timeval(tv_sec: 2, tv_usec: 0)
                setsockopt(client, SOL_SOCKET, SO_NOSIGPIPE, &noPipe, socklen_t(MemoryLayout.size(ofValue: noPipe)))
                setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, &timeout, socklen_t(MemoryLayout.size(ofValue: timeout)))
                setsockopt(client, SOL_SOCKET, SO_SNDTIMEO, &timeout, socklen_t(MemoryLayout.size(ofValue: timeout)))
                var data = Data(); var buffer = [UInt8](repeating: 0, count: 4096)
                while data.count < 65536 {
                    let n = recv(client, &buffer, buffer.count, 0)
                    if n <= 0 { break }
                    data.append(contentsOf: buffer.prefix(n))
                    if data.contains(10) { break }
                }
                guard data.count < 65536, let line = data.split(separator: 10).first,
                      let request = (try? JSONSerialization.jsonObject(with: Data(line))) as? [String: Any] else { Darwin.close(client); continue }
                let semaphore = DispatchSemaphore(value: 0)
                let box = ResponseBox()
                DispatchQueue.main.async {
                    let answer = handler(request)
                    box.data = (try? JSONSerialization.data(withJSONObject: answer)) ?? Data("{}".utf8)
                    semaphore.signal()
                }
                if semaphore.wait(timeout: .now() + 3) == .success {
                    var response = box.data; response.append(10)
                    response.withUnsafeBytes { bytes in
                        var sent = 0
                        while sent < bytes.count {
                            let n = send(client, bytes.baseAddress!.advanced(by: sent), bytes.count - sent, 0)
                            if n <= 0 { break }; sent += n
                        }
                    }
                }
                Darwin.close(client)
            }
        }
    }
    deinit { shutdown(socketFD, SHUT_RDWR); Darwin.close(socketFD); unlink(Self.path) }
}
private final class ResponseBox { var data = Data() }
