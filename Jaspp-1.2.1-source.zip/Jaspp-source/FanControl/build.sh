#!/bin/bash
set -euo pipefail
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SOURCE_DIR")"
BUILD_DIR="${JASPP_BUILD_DIR:-}"
if [ -z "$BUILD_DIR" ]; then
  BUILD_DIR="$(mktemp -d "${TMPDIR:-/tmp}/jaspp-build.XXXXXX")"
  trap 'rm -rf "$BUILD_DIR"' EXIT
fi
APP_DIR="$PROJECT_DIR/Jaspp Fans Control.app"
mkdir -p "$BUILD_DIR/cache" "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"
clang -O2 -mmacosx-version-min=14.0 -c "$SOURCE_DIR/SMC.c" -o "$BUILD_DIR/SMC.o"
FLAGS=(-O -target arm64-apple-macos14.0 -swift-version 5 -module-cache-path "$BUILD_DIR/cache" -import-objc-header "$SOURCE_DIR/SMC.h")
swiftc "${FLAGS[@]}" "$SOURCE_DIR/Core.swift" "$SOURCE_DIR/Service.swift" "$SOURCE_DIR/Helper.swift" "$BUILD_DIR/SMC.o" -framework IOKit -o "$APP_DIR/Contents/Resources/JasppFanHelper"
swiftc "${FLAGS[@]}" "$SOURCE_DIR/Core.swift" "$SOURCE_DIR/Service.swift" "$SOURCE_DIR/Bridge.swift" "$SOURCE_DIR/App.swift" "$SOURCE_DIR/Design.swift" "$BUILD_DIR/SMC.o" -framework IOKit -framework AppKit -framework SwiftUI -framework Charts -o "$APP_DIR/Contents/MacOS/JasppFansControl"
swiftc "${FLAGS[@]}" -D TESTING "$SOURCE_DIR/Core.swift" "$SOURCE_DIR/Service.swift" "$SOURCE_DIR/Helper.swift" "$SOURCE_DIR/Tests.swift" "$BUILD_DIR/SMC.o" -framework IOKit -o "$BUILD_DIR/tests"
"$BUILD_DIR/tests"
cp "$SOURCE_DIR/Info.plist" "$APP_DIR/Contents/Info.plist"
if [ -f "$PROJECT_DIR/Jaspp.icns" ]; then cp "$PROJECT_DIR/Jaspp.icns" "$APP_DIR/Contents/Resources/Jaspp.icns"; fi
codesign --force --sign - "$APP_DIR/Contents/Resources/JasppFanHelper"
codesign --force --sign - "$APP_DIR"
codesign --verify --deep --strict "$APP_DIR"
echo "Built: $APP_DIR"
