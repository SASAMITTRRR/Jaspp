#include "SMC.h"
#include <IOKit/IOKitLib.h>
#include <mach/mach.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>

/* AppleSMC user-client wire layout; independently implemented protocol adapter. */
typedef struct {
    uint32_t key;
    struct { uint8_t major, minor, build, reserved; uint16_t release; } version;
    struct { uint16_t version, length; uint32_t cpu, gpu, memory; } limits;
    struct { uint32_t size, type; uint8_t attributes; } info;
    uint8_t result, status, command;
    uint32_t index;
    uint8_t bytes[32];
} Packet;
_Static_assert(sizeof(Packet)==80, "SMC packet layout");
_Static_assert(offsetof(Packet,bytes)==48, "SMC byte offset");
static io_connect_t connection;
static char error_text[160];
static uint32_t four(const char *s) { return (uint32_t)(uint8_t)s[0]<<24 | (uint32_t)(uint8_t)s[1]<<16 | (uint32_t)(uint8_t)s[2]<<8 | (uint8_t)s[3]; }
const char *jf_error(void) { return error_text; }
int jf_open(void) {
    if (connection) return 0;
    io_service_t service=IOServiceGetMatchingService(kIOMainPortDefault,IOServiceMatching("AppleSMC"));
    if (!service) { snprintf(error_text,sizeof(error_text),"AppleSMC service unavailable"); return -1; }
    kern_return_t r=IOServiceOpen(service,mach_task_self(),0,&connection);
    IOObjectRelease(service);
    if(r) { connection=0; snprintf(error_text,sizeof(error_text),"AppleSMC open: 0x%x",r); }
    return r;
}
void jf_close(void) { if(connection) IOServiceClose(connection); connection=0; }
static int call(Packet *in, Packet *out) {
    if(jf_open()) return -1;
    memset(out,0,sizeof(*out)); size_t n=sizeof(*out);
    kern_return_t r=IOConnectCallStructMethod(connection,2,in,sizeof(*in),out,&n);
    if(r || out->result) { snprintf(error_text,sizeof(error_text),"SMC request: 0x%x / %u",r,out->result); return r ? (int)r : -out->result; }
    return 0;
}
static int read_raw(const char *key, Packet *out) {
    if(strlen(key)!=4) return -1;
    Packet in={0}, info={0}; in.key=four(key); in.command=9;
    int r=call(&in,&info); if(r) return r;
    if(info.info.size>32 || !info.info.size) return -1;
    in.info=info.info; in.command=5; r=call(&in,out); out->info=info.info; return r;
}
int jf_read(const char *key, double *value) {
    Packet p; int r=read_raw(key,&p); if(r) return r;
    uint32_t type=p.info.type; uint8_t *b=p.bytes;
    if(type==four("flt ") && p.info.size==4) { float f; memcpy(&f,b,4); *value=f; }
    else if(type==four("ui8 ")) *value=b[0];
    else if(type==four("ui16")) *value=(b[0]<<8)|b[1];
    else if(type==four("ui32")) *value=(uint32_t)b[0]<<24|(uint32_t)b[1]<<16|(uint32_t)b[2]<<8|b[3];
    else if(type==four("fpe2")) *value=((b[0]<<8)|b[1])/4.0;
    else if(type==four("sp78")) *value=(int16_t)((b[0]<<8)|b[1])/256.0;
    else return -1;
    return isfinite(*value) ? 0 : -1;
}
int jf_key(int index, char *key) {
    Packet in={0}, out={0}; in.command=8; in.index=index;
    int r=call(&in,&out); if(r) return r;
    for(int i=0;i<4;i++) key[i]=(out.key>>(24-i*8))&255;
    key[4]=0; return 0;
}
int jf_write(const char *key, double value) {
    if(!isfinite(value)||value<0||value>20000) return -1;
    Packet current; int r=read_raw(key,&current); if(r) return r;
    Packet in={0}, out={0}; in.key=four(key); in.info=current.info; in.command=6;
    if(current.info.type==four("flt ") && current.info.size==4) { float f=value; memcpy(in.bytes,&f,4); }
    else if(current.info.type==four("fpe2") && value<=16383) { unsigned n=(unsigned)lround(value*4); in.bytes[0]=n>>8; in.bytes[1]=n&255; }
    else if(current.info.type==four("ui8 ") && value<=255) in.bytes[0]=value;
    else if(current.info.type==four("ui16") && value<=65535) { unsigned n=value; in.bytes[0]=n>>8; in.bytes[1]=n&255; }
    else return -1;
    return call(&in,&out);
}
