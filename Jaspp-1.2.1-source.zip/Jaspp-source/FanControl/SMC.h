#include <stdint.h>
int jf_open(void);
void jf_close(void);
int jf_read(const char *key, double *value);
int jf_key(int index, char *key);
int jf_write(const char *key, double value);
const char *jf_error(void);
