import Foundation
import Darwin
@main struct Tests {
    static func main() throws {
        var checks = 0
        func check(_ condition: @autoclosure () -> Bool, _ message: String) {
            guard condition() else { fatalError(message) }; checks += 1
        }
        let fan = Fan(id: 0, rpm: 2400, minimum: 2317, maximum: 6800)
        let c = FanCurve()
        for (t, rpm) in zip([30.0,45,55,65,75,85,110], [2400.0,2400,3000,4000,5000,6800,6800]) {
            check(c.rpm(at: t, maximum: 6800) == rpm, "curve node \(t)")
        }
        check(c.rpm(at: 60, maximum: 6800) == 3500, "linear interpolation")
        for p in Preset.allCases where p != .system && p != .off {
            check(p.target(temperature: 60, fan: fan, curve: c) != nil, "preset target")
        }
        let small = Fan(id: 0, rpm: 1000, minimum: 3000, maximum: 4800)
        check(Preset.off.target(temperature: nil, fan: fan, curve: c) == nil, "unsupported stop must not become minimum RPM")
        check(Preset.off.target(temperature: nil, fan: Fan(id: 0, rpm: 1000, minimum: 0, maximum: 6800), curve: c) == 0, "supported stop requests zero RPM")
        check(Preset.rpm2400.target(temperature: nil, fan: small, curve: c) == 3000, "minimum clamp")
        check(Preset.rpm5000.target(temperature: nil, fan: small, curve: c) == 4800, "maximum clamp")
        check(Preset.full.target(temperature: nil, fan: fan, curve: c) == 6800, "full speed uses hardware maximum")
        check(Preset.temperature.target(temperature: nil, fan: fan, curve: c) == nil, "missing sensor fails closed")
        check(Preset.system.target(temperature: 60, fan: fan, curve: c) == nil, "system mode never writes target")
        check(!FanCurve(thresholds: [45,55,50,75,85]).valid, "reject reversed curve")
        check(!FanCurve(thresholds: [45,46,65,75,85]).valid, "reject narrow spacing")
        check(!FanCurve(thresholds: []).valid, "reject incomplete curve")
        let req = ControlRequest(token: "token", timestamp: 100, preset: .rpm2400, curve: c, sensor: "chip-max")
        check(req.valid(for: "token", now: 101), "fresh heartbeat")
        check(!req.valid(for: "token", now: 109), "stale heartbeat rejected")
        check(!req.valid(for: "other", now: 101), "wrong token rejected")
        check(!req.valid(for: "token", now: 90), "future heartbeat rejected")
        var hot = HotLoweringGuard()
        check(!hot.block(temperature: 99, critical: false, lowering: true, now: 0), "ordinary lowering is immediate")
        check(!hot.block(temperature: 103, critical: false, lowering: false, now: 1), "never block increasing speed")
        check(hot.block(temperature: 103, critical: false, lowering: true, now: 2), "block first hot lowering")
        check(!hot.block(temperature: 103, critical: false, lowering: true, now: 3), "second explicit lowering is allowed")
        hot.observe(temperature: 89, critical: false, now: 4)
        hot.observe(temperature: 89, critical: false, now: 13)
        check(hot.warned, "short cooling does not reset guard")
        hot.observe(temperature: 89, critical: false, now: 14)
        check(!hot.warned, "reset after ten seconds below 90")
        check(hot.block(temperature: 101, critical: false, lowering: true, now: 15), "next hot episode warns once")
        var critical = HotLoweringGuard()
        check(critical.block(temperature: 85, critical: true, lowering: true, now: 0), "system critical state warns")
        for p in [Preset.full,.rpm2400,.rpm5000,.rpm3000,.rpm2400] {
            let expected: Double = [.full:6800,.rpm2400:2400,.rpm5000:5000,.rpm3000:3000][p]!
            check(p.target(temperature: 102, fan: fan, curve: c) == expected, "preset target independent of previous speed or high temperature")
        }
        let dir = URL(fileURLWithPath: "/private/tmp/jaspp-fans-test-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        defer { try? FileManager.default.removeItem(at: dir) }
        guard let session = SessionDirectory(path: dir.path, uid: getuid()) else { fatalError("private directory accepted") }
        check(session.request() == nil, "missing request")
        let file = dir.appendingPathComponent("request.json")
        try JSONEncoder().encode(req).write(to: file)
        check(session.request()?.token == "token", "request decode")
        try FileManager.default.removeItem(at: file)
        try FileManager.default.createSymbolicLink(atPath: file.path, withDestinationPath: "/etc/passwd")
        check(session.request() == nil, "symlink rejected")
        try FileManager.default.removeItem(at: file)
        try Data(repeating: 32, count: 9000).write(to: file)
        check(session.request() == nil, "oversized request rejected")
        session.status(HelperStatus(timestamp: 100, running: true, preset: .rpm2400, applied: ["0":2400]))
        let status = try JSONDecoder().decode(HelperStatus.self, from: Data(contentsOf: dir.appendingPathComponent("status.json")))
        check(status.applied["0"] == 2400, "atomic status write")
        check(SessionDirectory(path: "/etc", uid: getuid()) == nil, "arbitrary path rejected")
        check(FanService.authorized(peer: 501, installedFor: 501), "service accepts the authorized account")
        check(!FanService.authorized(peer: 502, installedFor: 501), "service rejects a different account")
        check(!FanService.authorized(peer: 0, installedFor: 501), "service does not grant other peer identities")
        check(!FanService.authorized(peer: 0, installedFor: 0), "service requires a real user")
        func decodeFrame(_ bytes: Data) -> [String: Any]? {
            var pair: [Int32] = [-1,-1]
            guard socketpair(AF_UNIX, SOCK_STREAM, 0, &pair) == 0 else { fatalError("socketpair") }
            defer { Darwin.close(pair[0]); Darwin.close(pair[1]) }
            FanService.configure(pair[0]); FanService.configure(pair[1])
            _ = bytes.withUnsafeBytes { Darwin.send(pair[0], $0.baseAddress, $0.count, 0) }
            shutdown(pair[0], SHUT_WR)
            return FanService.receive(pair[1])
        }
        check(decodeFrame(Data("{\"action\":\"ping\"}\n".utf8))?["action"] as? String == "ping", "service decodes a complete bounded frame")
        check(decodeFrame(Data("{\"action\":\"ping\"}".utf8)) == nil, "incomplete frame rejected")
        check(decodeFrame(Data("not json\n".utf8)) == nil, "malformed frame rejected")
        check(decodeFrame(Data("[]\n".utf8)) == nil, "non-object frame rejected")
        check(decodeFrame(Data(repeating: 32, count: 4096)) == nil, "oversized service frame rejected")
        print("\(checks) checks passed: curve, bounds, presets, lease expiry, request identity and symlink handling.")
    }
}
