import AppKit
import SwiftUI
import Charts
import Combine

struct Reading: Identifiable {
    var id = UUID()
    var time: Date
    var fan: String
    var rpm: Double
}

@MainActor final class FanModel: ObservableObject {
    static let shared = FanModel()
    @Published var fans: [Fan] = []
    @Published var sensors: [Sensor] = []
    @Published var history: [Reading] = []
    @Published var preset: Preset = .system
    @Published var curve = FanCurve()
    @Published var sensor = "chip-max"
    @Published var error: String?
    @Published var authorizing = false
    @Published var installingService = false
    @Published var controlActive = false
    @Published var confirmedPreset: Preset = .system
    @Published var pendingChange = false
    @Published var applied: [String: Double] = [:]
    @Published var lastUpdate: Date?
    @Published var search = ""
    @Published var settings = false
    @Published var menuTemperature = true
    let queue = DispatchQueue(label: "app.jaspp.fans.monitor")
    nonisolated(unsafe) let hw = Hardware() // Accessed only on the serial monitor queue.
    var timer: Timer?
    var directory: URL?
    var token = ""
    var polling = false
    var authCompleted: Date?
    var changeSentAt: Date?
    var hotGuard = HotLoweringGuard()
    var notificationTokens: [NSObjectProtocol] = []

    var chipTemperature: Double? { sensors.filter(\.isChip).map(\.temperature).max() }
    var selectedTemperature: Double? { sensor == "chip-max" ? chipTemperature : sensors.first(where: { $0.id == sensor })?.temperature }
    var filteredSensors: [Sensor] {
        sensors.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) || $0.id.localizedCaseInsensitiveContains(search) }
    }
    var statusText: String {
        if authorizing { return installingService ? "首次安装控制组件，等待管理员授权…" : "正在连接后台控制组件…" }
        if pendingChange { return "正在切换 · \(preset.title)" }
        if controlActive { return "正在控制 · \(preset.title)" }
        return "系统自动控制"
    }
    init() {
        if let d = UserDefaults.standard.data(forKey: "curve"), let c = try? JSONDecoder().decode(FanCurve.self, from: d), c.valid { curve = c }
        sensor = UserDefaults.standard.string(forKey: "sensor") ?? "chip-max"
        notificationTokens.append(NSWorkspace.shared.notificationCenter.addObserver(forName: NSWorkspace.willSleepNotification, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.restore() }
        })
        queue.async { [weak self] in
            guard let self else { return }
            self.hw.discover()
            DispatchQueue.main.async { self.tick() }
        }
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
    }
    func tick() {
        heartbeat()
        inspectHelper()
        guard !polling else { return }
        polling = true
        queue.async { [weak self] in
            guard let self else { return }
            let f = self.hw.fans(), s = self.hw.sensors(), e = self.hw.error
            DispatchQueue.main.async {
                self.polling = false
                self.fans = f; self.sensors = s; self.lastUpdate = Date()
                self.hotGuard.observe(temperature: self.chipTemperature, critical: ProcessInfo.processInfo.thermalState == .critical, now: Date().timeIntervalSince1970)
                if f.isEmpty && self.error == nil { self.error = "暂时无法读取风扇。\(e)" }
                let now = Date()
                self.history += f.map { Reading(time: now, fan: $0.name, rpm: $0.rpm) }
                self.history.removeAll { now.timeIntervalSince($0.time) > 120 }
            }
        }
    }
    func heartbeat() {
        guard let dir = directory else { return }
        let req = ControlRequest(token: token, timestamp: Date().timeIntervalSince1970, preset: preset, curve: curve, sensor: sensor)
        do { try JSONEncoder().encode(req).write(to: dir.appendingPathComponent("request.json"), options: .atomic) }
        catch { self.error = "控制连接中断：\(error.localizedDescription)" }
    }
    func inspectHelper() {
        guard let dir = directory, !authorizing else { return }
        if let data = try? Data(contentsOf: dir.appendingPathComponent("status.json")), let status = try? JSONDecoder().decode(HelperStatus.self, from: data) {
            if Date().timeIntervalSince1970 - status.timestamp < 7 {
                controlActive = status.running
                confirmedPreset = status.preset
                if status.preset == preset, status.timestamp >= (changeSentAt?.timeIntervalSince1970 ?? 0) { pendingChange = false }
                applied = status.applied
                if let message = status.error { error = message }
                if !status.running { preset = .system; confirmedPreset = .system; pendingChange = false; directory = nil; authCompleted = nil }
                return
            }
        }
        if let completed = authCompleted, Date().timeIntervalSince(completed) > 12 {
            error = "控制组件没有响应；正在恢复系统自动。"
            restore()
            directory = nil; authCompleted = nil
        }
    }
    @discardableResult func choose(_ p: Preset, remote: Bool = false) -> [String: Any] {
        error = nil
        guard FanOwnership.shared.owns else { return ["ok":false,"error":"另一个 Jaspp 风扇控制实例正在运行，请退出它后重启当前应用。"] }
        guard !authorizing else { return ["ok":false,"error":installingService ? "请先在 Mac 上完成首次安装授权。" : "控制组件正在连接，请稍候。"] }
        if p == .system { restore(); return ["ok":true] }
        guard !fans.isEmpty, fans.allSatisfy(\.rangeValid), chipTemperature != nil else {
            error = "没有有效的风扇或芯片温度读数，暂时不能启用手动控制。"; return ["ok":false,"error":error!]
        }
        if p == .off, fans.contains(where: { $0.minimum > 0 }) {
            error = "当前硬件接口不支持 0 RPM 停转（最低 \(Int(fans.map(\.minimum).max() ?? 0)) RPM）。已保留当前档位。"
            return ["ok":false,"error":error!]
        }
        guard let update = lastUpdate, Date().timeIntervalSince(update) < 3 else { return ["ok":false,"error":"读数已过期，请等待刷新后重试。"] }
        let lowering = fans.contains { f in
            guard let target = p.target(temperature: selectedTemperature, fan: f, curve: curve) else { return false }
            let current = (f.target ?? 0) > 0 ? f.target! : f.rpm
            return target < current - 50
        }
        if hotGuard.block(temperature: chipTemperature, critical: ProcessInfo.processInfo.thermalState == .critical, lowering: lowering, now: Date().timeIntervalSince1970) {
            let message = String(format: "当前芯片热点 %.1f°C。本次降低转速已暂停，保持现有设定。同一轮高温只提醒一次；再次选择档位将按你的设定执行。", chipTemperature ?? 0)
            if !remote {
                let alert = NSAlert(); alert.alertStyle = .warning; alert.messageText = "当前温度较高"; alert.informativeText = message; alert.addButton(withTitle: "知道了")
                if let window = NSApp.keyWindow ?? NSApp.windows.first(where: { $0.contentView != nil }) {
                    window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true); alert.beginSheetModal(for: window) { _ in }
                }
            }
            return ["ok":false,"blocked":true,"message":message]
        }
        preset = p
        pendingChange = true; changeSentAt = Date()
        if directory != nil { heartbeat(); return ["ok":true,"pending":true] }
        startSession()
        return ["ok":true,"authorizing":authorizing,"pending":true]
    }
    private func startSession() {
        guard let helper = Bundle.main.url(forResource: "JasppFanHelper", withExtension: nil) else { error = "缺少控制组件。"; preset = .system; return }
        var template = Array("/private/tmp/jaspp-fans-XXXXXX".utf8CString)
        guard let result = mkdtemp(&template) else { error = "无法创建控制会话。"; preset = .system; return }
        let dir = URL(fileURLWithPath: String(cString: result))
        directory = dir; token = UUID().uuidString; authorizing = true; controlActive = false
        heartbeat()
        let shellQuote: (String) -> String = { "'" + $0.replacingOccurrences(of: "'", with: "'\\''") + "'" }
        let command = [helper.path, "--install", String(getuid())].map(shellQuote).joined(separator: " ")
        let escaped = command.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"")
        let script = "do shell script \"\(escaped)\" with administrator privileges with prompt \"安装 Jaspp 风扇控制组件。安装一次后，切换档位和重新打开应用无需再次输入密码。\""
        let request: [String: Any] = ["action":"start", "directory":dir.path, "token":token]
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            do {
                var response = FanService.call(request)
                if response == nil {
                    // Allow launchd to finish starting an already installed service.
                    for _ in 0..<10 {
                        usleep(100_000); response = FanService.call(request)
                        if response != nil { break }
                    }
                }
                if response == nil {
                    guard !FanService.installed else {
                        throw NSError(domain: "Jaspp", code: 3, userInfo: [NSLocalizedDescriptionKey:"后台控制组件已安装但尚未响应。请确认系统设置允许 Jaspp 后台运行，或重启 Mac 后重试。无需重复授权。"])
                    }
                    DispatchQueue.main.async { self?.installingService = true }
                    let process = Process(); process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript"); process.arguments = ["-e", script]
                    let pipe = Pipe(); process.standardError = pipe; process.standardOutput = FileHandle.nullDevice
                    try process.run(); process.waitUntilExit()
                    let text = String(decoding: pipe.fileHandleForReading.readDataToEndOfFile(), as: UTF8.self)
                    guard process.terminationStatus == 0 else {
                        throw NSError(domain: "Jaspp", code: 1, userInfo: [NSLocalizedDescriptionKey:"后台组件未安装：" + text.trimmingCharacters(in: .whitespacesAndNewlines)])
                    }
                    for _ in 0..<30 {
                        response = FanService.call(request)
                        if response != nil { break }
                        usleep(100_000)
                    }
                }
                for _ in 0..<25 where response?["busy"] as? Bool == true {
                    usleep(100_000); response = FanService.call(request)
                }
                guard response?["ok"] as? Bool == true else {
                    throw NSError(domain: "Jaspp", code: 2, userInfo: [NSLocalizedDescriptionKey:response?["error"] as? String ?? "后台控制组件未响应，请重新打开 Jaspp 后重试。"])
                }
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.authorizing = false; self.installingService = false; self.authCompleted = Date(); self.heartbeat()
                }
            } catch {
                DispatchQueue.main.async {
                    self?.authorizing = false; self?.installingService = false; self?.error = error.localizedDescription
                    self?.preset = .system; self?.pendingChange = false; self?.directory = nil
                }
            }
        }
    }

    func restore() {
        preset = .system; pendingChange = directory != nil; changeSentAt = Date(); heartbeat(); controlActive = false; applied = [:]
        // Keep the directory and command alive until the helper confirms restore.
        if directory != nil && authCompleted == nil { authCompleted = Date() }
    }
    func saveSettings() {
        guard curve.valid else { return }
        UserDefaults.standard.set(try? JSONEncoder().encode(curve), forKey: "curve")
        UserDefaults.standard.set(sensor, forKey: "sensor")
        heartbeat()
    }
    func exportDiagnostics() {
        let panel = NSSavePanel(); panel.nameFieldStringValue = "Jaspp-Fans-diagnostics.json"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        struct Diagnostic: Encodable { var date: Date; var fans: [Fan]; var sensors: [Sensor]; var preset: Preset; var error: String? }
        do {
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            try encoder.encode(Diagnostic(date: Date(), fans: fans, sensors: sensors, preset: preset, error: error)).write(to: url, options: .atomic)
        } catch { self.error = error.localizedDescription }
    }
    func bridge(_ request: [String: Any]) -> [String: Any] {
        switch request["action"] as? String {
        case "state": return snapshot()
        case "preset":
            guard let raw = request["preset"] as? String, let preset = Preset(rawValue: raw) else { return ["ok":false,"error":"未知风扇档位。"] }
            var result = choose(preset, remote: true); result["state"] = snapshot(); return result
        default: return ["ok":false,"error":"未知风扇操作。"]
        }
    }
    func snapshot() -> [String: Any] {
        func encoded<T: Encodable>(_ value: T) -> Any { (try? JSONSerialization.jsonObject(with: JSONEncoder().encode(value))) ?? NSNull() }
        let cpu = sensors.first(where: { $0.id == "TCMz" }) ?? sensors.filter(\.isChip).max(by: { $0.temperature < $1.temperature })
        let gpu = sensors.filter { $0.id.hasPrefix("Tg") || $0.id.hasPrefix("TG") }.max(by: { $0.temperature < $1.temperature })
        let battery = sensors.first(where: { $0.id == "TB0T" }) ?? sensors.first(where: { $0.id.hasPrefix("TB") })
        return ["ok":true,"available":!fans.isEmpty,"preset":preset.rawValue,"confirmedPreset":confirmedPreset.rawValue,
            "pending":pendingChange,"authorizing":authorizing,"controlActive":controlActive,"status":statusText,
            "fans":encoded(fans),"sensors":encoded(sensors),"applied":applied,"error":error as Any? ?? NSNull(),
            "temperatures":["cpu":cpu.map { $0.temperature as Any } ?? NSNull(),"gpu":gpu.map { $0.temperature as Any } ?? NSNull(),"battery":battery.map { $0.temperature as Any } ?? NSNull()],
            "updatedAt":lastUpdate?.timeIntervalSince1970 as Any? ?? NSNull()]
    }
}

struct CurveSettings: View {
    @ObservedObject var model: FanModel
    @Environment(\.dismiss) var dismiss
    @State var draft = FanCurve()
    @State var sensor = "chip-max"
    let rpms = ["2400 RPM", "3000 RPM", "4000 RPM", "5000 RPM", "满速"]
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("按温度调节").font(.title2.bold())
            Text("相邻节点之间按温度线性计算目标。目标立即提交，不做缓降。每个风扇按自身支持范围限制转速。")
                .font(.subheadline).foregroundStyle(.secondary)
            Picker("控制温度", selection: $sensor) {
                Text("最高芯片温度（推荐）").tag("chip-max")
                ForEach(model.sensors) { s in Text(s.name).tag(s.id) }
            }
            ForEach(0..<5, id: \.self) { i in
                HStack {
                    Text(rpms[i]).frame(width: 100, alignment: .leading)
                    Stepper(value: $draft.thresholds[i], in: 25...100, step: 1) {
                        Text("\(Int(draft.thresholds[i]))°C").monospacedDigit().frame(width: 65, alignment: .trailing)
                    }
                }
            }
            if !draft.valid { Text("温度节点需要从低到高排列，间隔至少 3°C。").font(.caption).foregroundStyle(.orange) }
            Text("芯片热点达到 100°C 或系统报告严重温度压力时，仅拦截一次降低转速并提示。低于 90°C 持续 10 秒后重置提醒。")
                .font(.caption).foregroundStyle(.secondary)
            Toggle("菜单栏显示温度", isOn: $model.menuTemperature)
            HStack {
                Button("恢复默认") { draft = FanCurve(); sensor = "chip-max" }
                Spacer()
                Button("取消") { dismiss() }.keyboardShortcut(.cancelAction)
                Button("保存") { model.curve = draft; model.sensor = sensor; model.saveSettings(); dismiss() }
                    .buttonStyle(.borderedProminent).disabled(!draft.valid).keyboardShortcut(.defaultAction)
            }
        }.padding(28).frame(width: 450)
            .onAppear { draft = model.curve; sensor = model.sensor }
    }
}

#if !JASPP_EMBEDDED
@MainActor final class FansAppDelegate: NSObject, NSApplicationDelegate {
    var instanceLock: Int32 = -1
    var model: FanModel!
    var window: NSWindow!
    var status: NSStatusItem!
    var subscription: AnyCancellable?
    var bridge: FanBridge?
    func applicationDidFinishLaunching(_ notification: Notification) {
        let selfTest = CommandLine.arguments.contains("--self-test")
        if !selfTest {
            guard FanOwnership.shared.owns else {
                NSRunningApplication.runningApplications(withBundleIdentifier: "app.jaspp.fanscontrol").first(where: { $0.processIdentifier != getpid() })?.activate()
                NSApp.terminate(nil); return
            }
        }
        model = FanModel.shared
        if !selfTest { bridge = FanBridge(handler: { [weak self] request in self?.model.bridge(request) ?? ["ok":false] }) }
        let view = FansDashboardView(model: model)
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1000, height: 790), styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        window.title = "Jaspp Fans Control"; window.isReleasedWhenClosed = false
        window.contentView = NSHostingView(rootView: view); window.center(); window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        status = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        status.button?.image = NSImage(systemSymbolName: "fan", accessibilityDescription: "Jaspp Fans Control")
        status.button?.imagePosition = .imageLeading
        let menu = NSMenu()
        let open = NSMenuItem(title: "打开 Jaspp Fans Control", action: #selector(showWindow), keyEquivalent: ""); open.target = self; menu.addItem(open)
        menu.addItem(.separator())
        for p in Preset.allCases {
            let item = NSMenuItem(title: p.title, action: #selector(selectPreset(_:)), keyEquivalent: "")
            item.representedObject = p.rawValue; item.target = self; menu.addItem(item)
        }
        menu.addItem(.separator())
        let quit = NSMenuItem(title: "恢复系统自动并退出", action: #selector(quitApp), keyEquivalent: "q"); quit.target = self; menu.addItem(quit)
        status.menu = menu
        subscription = model.objectWillChange.sink { [weak self] _ in
            DispatchQueue.main.async { self?.updateMenu() }
        }
        let mainMenu = NSMenu()
        let appMenu = NSMenu(); let top = NSMenuItem(); top.submenu = appMenu; mainMenu.addItem(top)
        let about = NSMenuItem(title: "关于 Jaspp Fans Control", action: #selector(aboutApp), keyEquivalent: ""); about.target = self; appMenu.addItem(about)
        appMenu.addItem(.separator())
        let mq = NSMenuItem(title: "退出 Jaspp Fans Control", action: #selector(quitApp), keyEquivalent: "q"); mq.target = self; appMenu.addItem(mq)
        NSApp.mainMenu = mainMenu
        if selfTest, let index = CommandLine.arguments.firstIndex(of: "--self-test"), CommandLine.arguments.count > index + 1 {
            let destination = URL(fileURLWithPath: CommandLine.arguments[index + 1])
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) { [self] in
                if let view = window.contentView, let bitmap = view.bitmapImageRepForCachingDisplay(in: view.bounds) {
                    view.cacheDisplay(in: view.bounds, to: bitmap)
                    try? bitmap.representation(using: .png, properties: [:])?.write(to: destination.appendingPathComponent("Jaspp-preview.png"))
                }
                let report: [String: Any] = ["fanCount": model.fans.count, "sensorCount": model.sensors.count,
                    "monitorHasLiveData": model.lastUpdate != nil, "manualControlEnabled": model.controlActive,
                    "rpm": model.fans.map(\.rpm), "minimum": model.fans.map(\.minimum), "maximum": model.fans.map(\.maximum),
                    "menuPresent": status.menu != nil, "presetCount": Preset.allCases.count - 1]
                if let data = try? JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]) {
                    try? data.write(to: destination.appendingPathComponent("运行验证.json"))
                }
                NSApp.terminate(nil)
            }
        }
    }
    func updateMenu() {
        var title = model.fans.first.map { " \(Int($0.rpm)) RPM" } ?? " —"
        if model.menuTemperature, let t = model.chipTemperature { title += " · \(Int(t))°" }
        status.button?.title = title
        status.button?.toolTip = model.statusText
        for item in status.menu?.items ?? [] {
            if let raw = item.representedObject as? String { item.state = raw == model.preset.rawValue ? .on : .off }
        }
    }
    @objc func showWindow() { window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true) }
    @objc func selectPreset(_ sender: NSMenuItem) { if let raw = sender.representedObject as? String, let p = Preset(rawValue: raw) { model.choose(p) } }
    @objc func quitApp() { NSApp.terminate(nil) }
    @objc func aboutApp() {
        NSApp.orderFrontStandardAboutPanel(options: [.applicationName: "Jaspp Fans Control", .applicationVersion: "1.0", .credits: NSAttributedString(string: "独立的本地风扇工具。六档控制、温控曲线与菜单栏监控全部内置。\n与 CrystalIDEA 无隶属关系。")])
    }
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        model?.restore()
        model?.timer?.invalidate()
        // Helper confirms restoration independently; crash watchdog also expires.
        return .terminateNow
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool { showWindow(); return true }
}

@main struct JasppApplication {
    @MainActor static func main() {
        let app = NSApplication.shared
        let delegate = FansAppDelegate(); app.delegate = delegate
        app.setActivationPolicy(.regular)
        withExtendedLifetime(delegate) { app.run() }
    }
}
#endif
