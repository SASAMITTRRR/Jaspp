import Foundation
@main struct Probe {
    static func main() {
        let h = Hardware()
        guard jf_open() == 0 else { print(h.error); exit(1) }
        h.discover()
        let payload = ["fans": try! JSONSerialization.jsonObject(with: JSONEncoder().encode(h.fans())),
                       "sensors": try! JSONSerialization.jsonObject(with: JSONEncoder().encode(h.sensors()))]
        let d = try! JSONSerialization.data(withJSONObject: payload, options: [.prettyPrinted, .sortedKeys])
        print(String(decoding: d, as: UTF8.self))
    }
}
