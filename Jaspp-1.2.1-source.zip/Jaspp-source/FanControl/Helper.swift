import Foundation
import Darwin

private var stopping = false
private var daemonSocket: Int32 = -1
private func stopSignal(_ s: Int32) {
    stopping = true
    if daemonSocket >= 0 { Darwin.close(daemonSocket); daemonSocket = -1 }
}

// Hold a directory descriptor throughout the session. Never follow a user-supplied
// status/command symlink or write privileged files outside this directory.
final class SessionDirectory {
    let fd: Int32
    let uid: uid_t
    init?(path: String, uid: uid_t) {
        guard uid > 0, path.hasPrefix("/private/tmp/jaspp-fans-"),
              !path.dropFirst("/private/tmp/jaspp-fans-".count).contains("/"),
              path.count < 140 else { return nil }
        let f = Darwin.open(path, O_RDONLY | O_DIRECTORY | O_NOFOLLOW)
        guard f >= 0 else { return nil }
        var st = stat()
        guard fstat(f, &st) == 0, st.st_uid == uid, st.st_mode & 0o077 == 0 else { Darwin.close(f); return nil }
        fd = f; self.uid = uid
    }
    deinit { Darwin.close(fd) }
    func request() -> ControlRequest? {
        let f = openat(fd, "request.json", O_RDONLY | O_NOFOLLOW | O_NONBLOCK)
        guard f >= 0 else { return nil }
        defer { Darwin.close(f) }
        var st = stat()
        guard fstat(f, &st) == 0, st.st_uid == uid, (st.st_mode & S_IFMT) == S_IFREG,
              st.st_size > 0, st.st_size < 8192 else { return nil }
        var bytes = [UInt8](repeating: 0, count: Int(st.st_size))
        let n = Darwin.read(f, &bytes, bytes.count)
        guard n == bytes.count else { return nil }
        return try? JSONDecoder().decode(ControlRequest.self, from: Data(bytes))
    }
    func status(_ status: HelperStatus) {
        guard let data = try? JSONEncoder().encode(status) else { return }
        let name = ".status-\(UUID().uuidString)"
        let f = openat(fd, name, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0o644)
        guard f >= 0 else { return }
        let written = data.withUnsafeBytes { Darwin.write(f, $0.baseAddress, $0.count) }
        Darwin.close(f)
        if written == data.count { _ = renameat(fd, name, fd, "status.json") }
        else { _ = unlinkat(fd, name, 0) }
    }
}

final class FanDriver {
    let hw = Hardware()
    var touched = false
    var targets: [Int: Double] = [:]
    func retry(_ key: String, _ value: Double, attempts: Int = 12) -> Bool {
        for _ in 0..<attempts {
            if stopping { return false }
            if hw.write(key, value) { return true }
            usleep(100_000)
        }
        return false
    }
    func manual(_ fan: Fan, target: Double) -> Bool {
        guard fan.rangeValid, target >= fan.minimum, target <= fan.maximum else { return false }
        touched = true
        let key = hw.modeKey(fan.id)
        if hw.read(key) != 1 {
            _ = hw.write(key, 1)
            for _ in 0..<5 { if hw.read(key) == 1 { break }; usleep(100_000) }
            if hw.read(key) != 1 {
                guard hw.read("Ftst") != nil, retry("Ftst", 1) else { return false }
                // Newer Apple Silicon firmware may need time to release control.
                guard retry(key, 1, attempts: 60) else { return false }
            }
        }
        guard retry("F\(fan.id)Tg", target) else { return false }
        var confirmed = false
        for _ in 0..<15 {
            if let actual = hw.read("F\(fan.id)Tg"), abs(actual - target) < 75, hw.read(key) == 1 { confirmed = true; break }
            usleep(100_000)
        }
        guard confirmed else { return false }
        targets[fan.id] = target
        return true
    }
    func restore() -> Bool {
        guard touched else { return true }
        var ok = !hw.fans().isEmpty
        // Reset modes first, then release the shared force/test switch.
        for fan in hw.fans() {
            let key = hw.modeKey(fan.id)
            var written = false
            for _ in 0..<15 {
                if hw.write(key, 0) { written = true; break }
                usleep(100_000)
            }
            ok = written && ok
        }
        if hw.read("Ftst") != nil { ok = hw.write("Ftst", 0) && ok }
        targets.removeAll()
        touched = false
        return ok
    }
}

#if !TESTING
@main struct JasppHelper {
    static func main() {
        let args = CommandLine.arguments
        if args.count == 3, args[1] == "--install", let uid = UInt32(args[2]), uid > 0, geteuid() == 0 {
            do { try install(uid: uid) } catch { fputs("安装后台组件失败：\(error)\n", stderr); exit(4) }
            return
        }
        if args.count == 3, args[1] == "--daemon", let uid = UInt32(args[2]), uid > 0, geteuid() == 0 {
            serve(uid: uid); return
        }
        guard geteuid() == 0, args.count == 4, let uid = UInt32(args[2]),
              let directory = SessionDirectory(path: args[1], uid: uid),
              UUID(uuidString: args[3]) != nil else { exit(2) }
        let token = args[3]
        signal(SIGTERM, stopSignal); signal(SIGINT, stopSignal); signal(SIGHUP, stopSignal)
        _ = runSession(directory: directory, token: token)
    }
    static func runSession(directory: SessionDirectory, token: String) -> Bool {
        let driver = FanDriver()
        guard jf_open() == 0 else {
            directory.status(HelperStatus(timestamp: Date().timeIntervalSince1970, running: false, preset: .system, error: driver.hw.error, applied: [:])); return false
        }
        driver.hw.discover()
        var failure: String?
        defer { jf_close() }
        while !stopping {
            guard let req = directory.request(), req.valid(for: token, now: Date().timeIntervalSince1970) else { break }
            if req.preset == .system { break }
            let fans = driver.hw.fans()
            guard !fans.isEmpty, fans.allSatisfy(\.rangeValid) else { failure = "没有读到有效的风扇转速范围。"; break }
            let sensors = driver.hw.sensors()
            let chipMaximum = sensors.filter(\.isChip).map(\.temperature).max()
            let selected = req.sensor == "chip-max" ? chipMaximum : sensors.first(where: { $0.id == req.sensor })?.temperature
            guard chipMaximum != nil else { failure = "芯片温度不可用，已交还系统控制。"; break }
            var applied: [String: Double] = [:]
            var valid = true
            for fan in fans {
                guard var target = req.preset.target(temperature: selected, fan: fan, curve: req.curve) else { valid = false; break }
                target = target.rounded()
                target = max(fan.minimum, min(fan.maximum, target))
                if driver.targets[fan.id] != target || driver.hw.read(driver.hw.modeKey(fan.id)) != 1 {
                    if !driver.manual(fan, target: target) { valid = false; break }
                }
                applied[String(fan.id)] = target
            }
            if !valid { failure = "硬件拒绝设置，或选定温度传感器不可用。已交还系统控制。"; break }
            directory.status(HelperStatus(timestamp: Date().timeIntervalSince1970, running: true, preset: req.preset, error: nil, applied: applied))
            usleep(500_000)
        }
        let restored = driver.restore()
        directory.status(HelperStatus(timestamp: Date().timeIntervalSince1970, running: false, preset: .system,
            error: restored ? failure : "恢复系统控制失败。请立即重启 Mac，并关闭其他风扇工具。", applied: [:]))
        return restored
    }
}
extension JasppHelper {
    static func rootDirectory(_ path: String) throws {
        var st = stat()
        if lstat(path, &st) != 0 {
            guard mkdir(path, 0o755) == 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno)) }
            guard lstat(path, &st) == 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno)) }
        }
        guard st.st_uid == 0, (st.st_mode & S_IFMT) == S_IFDIR, st.st_mode & 0o022 == 0 else {
            throw NSError(domain: "Jaspp", code: 1, userInfo: [NSLocalizedDescriptionKey:"后台目录权限不正确：\(path)"])
        }
    }
    static func launchctl(_ args: [String], required: Bool = true) throws {
        let p = Process(); p.executableURL = URL(fileURLWithPath: "/bin/launchctl"); p.arguments = args
        p.standardOutput = FileHandle.nullDevice; p.standardError = FileHandle.nullDevice
        try p.run(); p.waitUntilExit()
        if required && p.terminationStatus != 0 { throw NSError(domain: "launchctl", code: Int(p.terminationStatus)) }
    }
    static func install(uid: uid_t) throws {
        guard getpwuid(uid) != nil else { throw NSError(domain: "Jaspp", code: 2) }
        try rootDirectory("/Library/PrivilegedHelperTools")
        try rootDirectory("/Library/LaunchDaemons")
        try rootDirectory(FanService.runtime)
        // Stop the old service first; its termination handler restores automatic control.
        try launchctl(["bootout", "system/" + FanService.label], required: false)
        let temporary = "/Library/PrivilegedHelperTools/.jaspp-" + UUID().uuidString
        defer { try? FileManager.default.removeItem(atPath: temporary) }
        try FileManager.default.copyItem(atPath: CommandLine.arguments[0], toPath: temporary)
        guard chown(temporary, 0, 0) == 0, chmod(temporary, 0o755) == 0,
              rename(temporary, FanService.binary) == 0 else { throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno)) }
        let plist: [String: Any] = ["Label":FanService.label,
            "ProgramArguments":[FanService.binary, "--daemon", String(uid)],
            "RunAtLoad":true, "KeepAlive":true, "ThrottleInterval":3, "ExitTimeOut":15,
            "ProcessType":"Background"]
        let data = try PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0)
        try data.write(to: URL(fileURLWithPath: FanService.plist), options: .atomic)
        guard chown(FanService.plist, 0, 0) == 0, chmod(FanService.plist, 0o644) == 0 else {
            throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
        }
        try launchctl(["bootstrap", "system", FanService.plist])
    }
    static func serve(uid: uid_t) {
        do { try rootDirectory(FanService.runtime) } catch { exit(5) }
        // One root service owns this SMC connection and serializes all sessions.
        let lockFD = Darwin.open(FanService.runtime + "/service.lock", O_RDWR | O_CREAT | O_NOFOLLOW, 0o600)
        guard lockFD >= 0, flock(lockFD, LOCK_EX | LOCK_NB) == 0 else { exit(6) }
        defer { Darwin.close(lockFD) }
        signal(SIGTERM, stopSignal); signal(SIGINT, stopSignal); signal(SIGHUP, stopSignal)
        let recovery = FanService.runtime + "/controlled"
        if FileManager.default.fileExists(atPath: recovery) {
            if jf_open() != 0 { exit(7) }
            let driver = FanDriver(); driver.hw.discover(); driver.touched = true
            guard driver.restore() else { jf_close(); exit(7) }
            jf_close(); try? FileManager.default.removeItem(atPath: recovery)
        }
        let fd = socket(AF_UNIX, SOCK_STREAM, 0)
        guard fd >= 0 else { exit(8) }
        daemonSocket = fd
        defer {
            if daemonSocket >= 0 { Darwin.close(fd); daemonSocket = -1 }
            unlink(FanService.socketPath)
        }
        unlink(FanService.socketPath)
        var addr = FanService.address(FanService.socketPath)
        let bound = withUnsafePointer(to: &addr) { p in p.withMemoryRebound(to: sockaddr.self, capacity: 1) {
            Darwin.bind(fd, $0, socklen_t(MemoryLayout<sockaddr_un>.size)) == 0
        } }
        guard bound, chmod(FanService.socketPath, 0o666) == 0, listen(fd, 8) == 0 else { exit(8) }
        let work = DispatchQueue(label: "app.jaspp.fans.session"), group = DispatchGroup(), mutex = NSLock()
        var busy = false
        while !stopping {
            let client = accept(fd, nil, nil)
            if client < 0 { if errno == EINTR && !stopping { continue }; break }
            FanService.configure(client)
            var peer: uid_t = 0, peerGroup: gid_t = 0
            let authorized = getpeereid(client, &peer, &peerGroup) == 0 && FanService.authorized(peer: peer, installedFor: uid)
            var answer: [String: Any] = ["ok":false, "revision":FanService.revision]
            if authorized, let request = FanService.receive(client) {
                if request["action"] as? String == "ping" { answer["ok"] = true }
                else if request["action"] as? String == "start",
                        let path = request["directory"] as? String,
                        let token = request["token"] as? String, UUID(uuidString: token) != nil,
                        let directory = SessionDirectory(path: path, uid: peer),
                        let command = directory.request(), command.valid(for: token, now: Date().timeIntervalSince1970) {
                    mutex.lock(); let available = !busy; if available { busy = true }; mutex.unlock()
                    if available {
                        answer["ok"] = true
                        group.enter()
                        work.async {
                            // A root-owned marker lets launchd recovery restore after a crash.
                            if FileManager.default.createFile(atPath: recovery, contents: Data(), attributes: [.posixPermissions:0o600]) {
                                if runSession(directory: directory, token: token) {
                                    try? FileManager.default.removeItem(atPath: recovery)
                                } else { stopSignal(SIGTERM) }
                            } else {
                                directory.status(HelperStatus(timestamp: Date().timeIntervalSince1970, running: false, preset: .system, error: "无法建立控制恢复记录。", applied: [:]))
                            }
                            mutex.lock(); busy = false; mutex.unlock(); group.leave()
                        }
                    } else { answer["busy"] = true; answer["error"] = "上一控制会话正在结束，请稍后重试。" }
                } else { answer["error"] = "无效的控制会话。" }
            } else { answer["error"] = "当前账户没有获得风扇控制授权。" }
            FanService.send(client, answer); Darwin.close(client)
        }
        group.wait()
    }
}

#endif
