import Foundation
import Darwin

// Fixed local protocol: no commands, executable paths or arbitrary SMC keys.
enum FanService {
    static let revision = 1
    static let label = "app.jaspp.fans.control"
    static let binary = "/Library/PrivilegedHelperTools/\(label)"
    static let plist = "/Library/LaunchDaemons/\(label).plist"
    static let runtime = "/private/var/run/jaspp-fans"
    static let socketPath = runtime + "/control.sock"

    static var installed: Bool {
        [binary, plist].allSatisfy { path in
            var st = stat()
            return lstat(path, &st) == 0 && st.st_uid == 0 &&
                (st.st_mode & S_IFMT) == S_IFREG && st.st_mode & 0o022 == 0
        }
    }

    static func authorized(peer: uid_t, installedFor uid: uid_t) -> Bool {
        uid > 0 && peer == uid
    }

    static func address(_ path: String) -> sockaddr_un {
        var addr = sockaddr_un()
        addr.sun_family = sa_family_t(AF_UNIX)
        addr.sun_len = UInt8(MemoryLayout<sockaddr_un>.size)
        let bytes = Array(path.utf8CString)
        precondition(bytes.count <= MemoryLayout.size(ofValue: addr.sun_path))
        withUnsafeMutableBytes(of: &addr.sun_path) { dst in bytes.withUnsafeBytes { dst.copyMemory(from: $0) } }
        return addr
    }
    static func configure(_ fd: Int32) {
        var timeout = timeval(tv_sec: 3, tv_usec: 0), noPipe: Int32 = 1
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, socklen_t(MemoryLayout.size(ofValue: timeout)))
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, socklen_t(MemoryLayout.size(ofValue: timeout)))
        setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &noPipe, socklen_t(MemoryLayout.size(ofValue: noPipe)))
    }
    static func receive(_ fd: Int32) -> [String: Any]? {
        var data = Data(), buffer = [UInt8](repeating: 0, count: 1024)
        while data.count < 4096 {
            let n = recv(fd, &buffer, min(buffer.count, 4096 - data.count), 0)
            guard n > 0 else { return nil }
            data.append(contentsOf: buffer.prefix(n))
            if let end = data.firstIndex(of: 10) {
                return (try? JSONSerialization.jsonObject(with: data.prefix(upTo: end))) as? [String: Any]
            }
        }
        return nil
    }
    @discardableResult static func send(_ fd: Int32, _ message: [String: Any]) -> Bool {
        guard var data = try? JSONSerialization.data(withJSONObject: message) else { return false }
        data.append(10)
        return data.withUnsafeBytes { raw in
            var sent = 0
            while sent < raw.count {
                let n = Darwin.send(fd, raw.baseAddress!.advanced(by: sent), raw.count - sent, 0)
                if n <= 0 { return false }
                sent += n
            }
            return true
        }
    }
    static func call(_ message: [String: Any]) -> [String: Any]? {
        let fd = socket(AF_UNIX, SOCK_STREAM, 0)
        guard fd >= 0 else { return nil }
        defer { Darwin.close(fd) }
        configure(fd)
        var addr = address(socketPath)
        let connected = withUnsafePointer(to: &addr) { p in
            p.withMemoryRebound(to: sockaddr.self, capacity: 1) { Darwin.connect(fd, $0, socklen_t(MemoryLayout<sockaddr_un>.size)) == 0 }
        }
        var peer: uid_t = 1, group: gid_t = 0
        guard connected, getpeereid(fd, &peer, &group) == 0, peer == 0,
              send(fd, message), let result = receive(fd), result["revision"] as? Int == revision else { return nil }
        return result
    }
}
