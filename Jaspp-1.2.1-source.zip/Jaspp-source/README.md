# Jaspp

macOS 菜单栏工具：风扇监控与温控曲线、局域网遥控、音量和 Apple Music 控制、内外屏亮度、锁屏/熄屏/关机，以及本机 Resend 写信台。

## 要求与构建

- Apple Silicon Mac，macOS 14 或更高；界面在较新 macOS 上可使用系统玻璃效果。
- 安装 Xcode Command Line Tools（`xcode-select --install`）。
- 需要 Python 3；程序使用 `/usr/bin/python3`（由 Command Line Tools 提供）。
- 在项目目录运行 `bash build.sh`，得到 `build/Jaspp.app`。构建会运行风扇逻辑测试并进行临时代码签名。

## 安装和使用

将 Jaspp.app 拖入 Applications。首次启用风扇控制时需要管理员授权，以安装常驻辅助服务。根据使用功能授权本地网络与自动化。外接屏控制依赖显示器的 DDC 支持。

公开分发版使用独立的数据目录 `~/Library/Application Support/Jaspp-Public`，不继承旧版的邮件密钥、记录或连接口令。连接口令首次启动随机生成。请仅把口令交给受信任的局域网设备；遥控使用 HTTP，适用于受信任的网络。

邮件功能默认未配置。在写信台设置中填写自己已在 Resend 验证的域名和自己的 API 密钥。密钥仅存放在本机数据目录中。example.com 只是占位符，不能用于发件。

风扇辅助服务有心跳租约、硬件转速范围限制以及退出/断连后的自动模式恢复；不同机型仍需自行验证，不支持没有风扇的机型。

## 分发状态

版本 1.2.1，公开清理构建。安装包为 Apple Silicon，使用临时签名，未经过 Apple 公证。Gatekeeper 可能拦截下载的应用；确认来源后在系统设置的隐私与安全性中允许打开。

本次验收包括重新构建、内置逻辑测试、邮件配置测试、隐私扫描和签名/镜像检查；没有启动发布应用操作真实风扇、发送邮件或执行关机。

## 第三方组件

`Python/bin/m1ddc` 来自 m1ddc 项目，许可证保留在同目录的 `m1ddc-LICENSE`。第三方署名不得作为个人信息清理掉。
