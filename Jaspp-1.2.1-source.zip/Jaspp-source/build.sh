#!/bin/bash
set -euo pipefail
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
TEMP_BUILD="$(mktemp -d "${TMPDIR:-/tmp}/jaspp-build.XXXXXX")"
trap 'rm -rf "$TEMP_BUILD"' EXIT
APP_DIR="$SOURCE_DIR/build/Jaspp.app"
mkdir -p "$TEMP_BUILD/cache" "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"
clang -O2 -mmacosx-version-min=14.0 -c "$SOURCE_DIR/FanControl/SMC.c" -o "$TEMP_BUILD/SMC.o"
FLAGS=(-O -swift-version 5 -target arm64-apple-macos14.0 -module-cache-path "$TEMP_BUILD/cache" -import-objc-header "$SOURCE_DIR/FanControl/SMC.h")
swiftc "${FLAGS[@]}" "$SOURCE_DIR/FanControl/Core.swift" "$SOURCE_DIR/FanControl/Service.swift" "$SOURCE_DIR/FanControl/Helper.swift" "$TEMP_BUILD/SMC.o" -framework IOKit -o "$APP_DIR/Contents/Resources/JasppFanHelper"
swiftc "${FLAGS[@]}" -D JASPP_EMBEDDED -parse-as-library "$SOURCE_DIR/FanControl/Core.swift" "$SOURCE_DIR/FanControl/Service.swift" "$SOURCE_DIR/FanControl/Bridge.swift" "$SOURCE_DIR/FanControl/App.swift" "$SOURCE_DIR/FanControl/Design.swift" "$SOURCE_DIR/MacApp/main.swift" "$TEMP_BUILD/SMC.o" -framework IOKit -framework AppKit -framework SwiftUI -framework Charts -framework ServiceManagement -o "$APP_DIR/Contents/MacOS/Jaspp"
swiftc "${FLAGS[@]}" -D TESTING "$SOURCE_DIR/FanControl/Core.swift" "$SOURCE_DIR/FanControl/Service.swift" "$SOURCE_DIR/FanControl/Helper.swift" "$SOURCE_DIR/FanControl/Tests.swift" "$TEMP_BUILD/SMC.o" -framework IOKit -o "$TEMP_BUILD/tests"
"$TEMP_BUILD/tests"
strip -x "$APP_DIR/Contents/MacOS/Jaspp" "$APP_DIR/Contents/Resources/JasppFanHelper"
ditto "$SOURCE_DIR/Python" "$APP_DIR/Contents/Resources/Python"
cp "$SOURCE_DIR/Info.plist" "$APP_DIR/Contents/Info.plist"
cp "$SOURCE_DIR/AppIcon.icns" "$APP_DIR/Contents/Resources/AppIcon.icns"
codesign --force --sign - "$APP_DIR/Contents/Resources/JasppFanHelper"
codesign --force --sign - "$APP_DIR"
codesign --verify --deep --strict "$APP_DIR"
echo "Built: $APP_DIR"
