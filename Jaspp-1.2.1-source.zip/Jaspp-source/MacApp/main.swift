import SwiftUI
import AppKit
import Combine
import ServiceManagement

struct DisplayState: Identifiable, Equatable {
    let id: Int
    var name: String
    var supported: Bool
    var brightness: Double
    var method: String
}

@MainActor
final class ServiceManager: ObservableObject {
    static let shared = ServiceManager()
    @Published var desired = true
    @Published var running = false
    @Published var port = 8765
    @Published var urls: [String] = []
    @Published var token = ""
    @Published var started = Date()
    @Published var configured = false
    @Published var mailDomain = ""
    @Published var song = "正在读取 Apple Music"
    @Published var artist = ""
    @Published var playing = false
    @Published var volume = 50.0
    @Published var displays: [DisplayState] = []
    @Published var recent: [[String: Any]] = []
    @Published var lastError = ""
    @Published var launchAtLogin = SMAppService.mainApp.status == .enabled
    private var process: Process?
    private var poller: Timer?
    private var restartWork: DispatchWorkItem?
    private var refreshing = false

    private init() {
        poller = Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.refresh() }
        }
    }

    var localURL: String { "http://127.0.0.1:\(port)" }
    var remoteURL: String { urls.first ?? "正在获取局域网地址…" }
    var uptime: String {
        let seconds = max(0, Int(Date().timeIntervalSince(started)))
        if seconds < 60 { return "\(seconds) 秒" }
        if seconds < 3600 { return "\(seconds / 60) 分钟" }
        return "\(seconds / 3600) 小时 \((seconds % 3600) / 60) 分"
    }

    func start() {
        desired = true
        guard process?.isRunning != true else { return }
        guard let script = Bundle.main.path(forResource: "server", ofType: "py", inDirectory: "Python") else {
            lastError = "找不到 Jaspp 服务组件。"; return
        }
        let data = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Jaspp-Public")
        try? FileManager.default.createDirectory(at: data, withIntermediateDirectories: true)
        let p = Process(); p.executableURL = URL(fileURLWithPath: "/usr/bin/python3"); p.arguments = [script]
        var env = ProcessInfo.processInfo.environment
        env["JASPP_DATA_DIR"] = data.path; env["JASPP_PORT"] = "8765"; p.environment = env
        let out = Pipe(); p.standardOutput = out; p.standardError = out
        out.fileHandleForReading.readabilityHandler = { [weak self] handle in
            let text = String(data: handle.availableData, encoding: .utf8) ?? ""
            guard !text.isEmpty else { return }
            Task { @MainActor in
                if text.contains("JASPP_READY") { self?.loadConnection(); self?.running = true; self?.started = Date(); self?.lastError = "" }
                else if text.contains("Traceback") || text.contains("Error") { self?.lastError = text.components(separatedBy: .newlines).last(where: { !$0.isEmpty }) ?? "服务异常" }
            }
        }
        p.terminationHandler = { [weak self] _ in
            Task { @MainActor in
                self?.running = false
                guard self?.desired == true else { return }
                let work = DispatchWorkItem { Task { @MainActor in self?.start() } }
                self?.restartWork = work
                DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: work)
            }
        }
        do { try p.run(); process = p }
        catch { lastError = "服务无法启动：\(error.localizedDescription)" }
    }

    func stop() {
        desired = false; restartWork?.cancel(); process?.terminate(); process = nil; running = false
    }

    func loadConnection() {
        let file = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Jaspp-Public/connection.json")
        guard let data = try? Data(contentsOf: file), let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
        port = obj["port"] as? Int ?? port; urls = obj["urls"] as? [String] ?? []; token = obj["token"] as? String ?? ""
        refresh()
    }

    func refresh() {
        guard desired, !refreshing else { return }
        if token.isEmpty { loadConnection() }
        guard let url = URL(string: localURL + "/app/state") else { return }
        refreshing = true
        URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data, error == nil, let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                Task { @MainActor in self?.refreshing = false }; return
            }
            Task { @MainActor in self?.refreshing = false; self?.apply(obj) }
        }.resume()
    }

    private func apply(_ obj: [String: Any]) {
        running = true; port = obj["port"] as? Int ?? port; urls = obj["urls"] as? [String] ?? urls
        token = obj["token"] as? String ?? token; configured = obj["configured"] as? Bool ?? false; mailDomain = obj["domain"] as? String ?? ""
        if let epoch = obj["started"] as? Double { started = Date(timeIntervalSince1970: epoch) }
        if let music = obj["music"] as? [String: Any] {
            song = music["name"] as? String ?? "尚未选择歌曲"; artist = music["artist"] as? String ?? ""; playing = (music["state"] as? String) == "playing"
        }
        if let v = obj["volume"] as? [String: Any], let n = v["value"] as? Double { volume = n }
        if let rawDisplays = obj["displays"] as? [[String: Any]] {
            let screenNames = Dictionary(uniqueKeysWithValues: NSScreen.screens.compactMap { screen -> (Int, String)? in
                guard let number = screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber else { return nil }
                return (number.intValue, screen.localizedName)
            })
            displays = rawDisplays.compactMap { raw in
                guard let id = (raw["id"] as? NSNumber)?.intValue else { return nil }
                let backendName = raw["name"] as? String ?? "显示器"
                return DisplayState(
                    id: id,
                    name: screenNames[id] ?? backendName,
                    supported: raw["supported"] as? Bool ?? false,
                    brightness: (raw["brightness"] as? NSNumber)?.doubleValue ?? 0,
                    method: raw["method"] as? String ?? "unsupported"
                )
            }
        }
        recent = obj["history"] as? [[String: Any]] ?? []
        if let errors = obj["errors"] as? [String: String], !errors.isEmpty { lastError = errors.values.first ?? "" } else { lastError = "" }
    }

    func post(_ path: String, body: [String: Any]) {
        guard let url = URL(string: localURL + path), let data = try? JSONSerialization.data(withJSONObject: body) else { return }
        var request = URLRequest(url: url); request.httpMethod = "POST"; request.httpBody = data
        request.setValue("application/json", forHTTPHeaderField: "Content-Type"); request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        URLSession.shared.dataTask(with: request) { [weak self] _, _, _ in DispatchQueue.main.asyncAfter(deadline: .now()+0.35) { Task { @MainActor in self?.refresh() } } }.resume()
    }

    func copy(_ value: String) { NSPasteboard.general.clearContents(); NSPasteboard.general.setString(value, forType: .string) }
    func airDrop(_ value: String) {
        guard let service = NSSharingService(named: .sendViaAirDrop) else { lastError = "这台 Mac 当前无法使用 AirDrop。"; return }
        service.perform(withItems: [URL(string: value) ?? value])
    }
    func setBrightness(id: Int) {
        guard let display = displays.first(where: { $0.id == id }) else { return }
        post("/remote/api/brightness", body: ["id":id, "value":display.brightness])
    }
    func setDisplayPower(id: Int, action: String) {
        post("/remote/api/display-power", body: ["id":id, "action":action])
    }
    func openMail() { if let u = URL(string: localURL + "/mail/") { NSWorkspace.shared.open(u) } }
    func openRemote() { if let u = URL(string: localURL + "/remote/") { NSWorkspace.shared.open(u) } }
    func setLaunchAtLogin(_ on: Bool) {
        do { if on { try SMAppService.mainApp.register() } else { try SMAppService.mainApp.unregister() }; launchAtLogin = on }
        catch { launchAtLogin = SMAppService.mainApp.status == .enabled; lastError = "开机启动设置失败：\(error.localizedDescription)" }
    }
}

struct SidebarButton: View {
    let title: String; let icon: String; let active: Bool; let action: () -> Void
    var body: some View {
        Button(action: action) { Label(title, systemImage: icon).frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 14).padding(.vertical, 14).background(active ? Color.white.opacity(0.55) : .clear).foregroundStyle(Color.primary.opacity(active ? 1 : 0.7)).clipShape(RoundedRectangle(cornerRadius: 22)) }
        .buttonStyle(.plain)
    }
}

struct ControlSlider: View {
    let title: String; let icon: String; @Binding var value: Double; let onCommit: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Label(title, systemImage: icon).font(.system(size: 14, weight: .semibold)); Spacer(); Text("\(Int(value))%").foregroundStyle(.secondary).monospacedDigit() }
            Slider(value: $value, in: 0...100, onEditingChanged: { if !$0 { onCommit() } }).tint(.blue)
        }
    }
}

struct MainView: View {
    @ObservedObject var manager = ServiceManager.shared
    @ObservedObject var fans = FanModel.shared
    @State private var page = 2
    var body: some View {
        HStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Jaspp").font(.system(size: 30, weight: .bold)).padding(.top, 34).padding(.bottom, 20)
                SidebarButton(title: "局域网遥控", icon: "display", active: page == 0) { page = 0 }
                SidebarButton(title: "风扇", icon: "fan", active: page == 2) { page = 2 }
                SidebarButton(title: "邮件发送", icon: "envelope", active: page == 1) { page = 1 }
                Spacer()
                Toggle("开机自动运行", isOn: Binding(get: { manager.launchAtLogin }, set: manager.setLaunchAtLogin)).toggleStyle(.switch).font(.system(size: 12)).tint(.blue)
                Text(manager.running ? "服务在线" : "服务离线").font(.caption).foregroundStyle(.secondary)
            }
            .padding(.horizontal, 18).padding(.bottom, 22).frame(width: 215).foregroundStyle(.primary).background(.ultraThinMaterial)
            if page == 2 { FansDashboardView(model: fans, embedded: true) }
            else { ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack(alignment: .center) {
                        VStack(alignment: .leading, spacing: 5) {
                            HStack(spacing: 11) { Text("Jaspp").font(.system(size: 26, weight: .semibold)); Circle().fill(manager.running ? .green : .gray).frame(width: 7, height: 7) }
                        }
                        Spacer()
                        Toggle("总开关", isOn: Binding(get: { manager.desired }, set: { $0 ? manager.start() : manager.stop() })).toggleStyle(.switch).tint(.blue)
                    }
                    if !manager.lastError.isEmpty { Text(manager.lastError).font(.caption).foregroundStyle(.orange).lineLimit(2) }
                    if page == 0 { remotePanel } else { mailPanel }
                    statusRail
                }.padding(28)
            }.background(JasppBackdrop()) }
        }.frame(minWidth: 920, minHeight: 650)
    }

    var remotePanel: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack { Label("局域网遥控", systemImage: "display").font(.title2.bold()); Spacer(); Text(manager.running ? "● 运行中" : "○ 已停止").foregroundStyle(manager.running ? .green : .secondary) }
            Divider()
            HStack(alignment: .top, spacing: 28) {
                VStack(spacing: 12) {
                    infoRow("本机局域网地址", manager.remoteURL, airDrop: true) { manager.copy(manager.remoteURL) }
                    infoRow("连接口令", manager.token.isEmpty ? "正在生成…" : manager.token) { manager.copy(manager.token) }
                    Divider()
                    HStack(spacing: 14) {
                        Image(systemName: "music.note").font(.title2).frame(width: 36, height: 36).background(Color.blue.opacity(0.1)).clipShape(RoundedRectangle(cornerRadius: 8))
                        VStack(alignment: .leading) { Text(manager.song).fontWeight(.semibold).lineLimit(1); Text(manager.artist.isEmpty ? "Apple Music" : manager.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                        Spacer()
                        Button { manager.post("/remote/api/music", body: ["action":"previous"]) } label: { Image(systemName: "backward.fill") }
                        Button { manager.post("/remote/api/music", body: ["action":"toggle"]) } label: { Image(systemName: manager.playing ? "pause.fill" : "play.fill").frame(width: 30, height: 30).background(Color.blue).foregroundStyle(.white).clipShape(Circle()) }.buttonStyle(.plain)
                        Button { manager.post("/remote/api/music", body: ["action":"next"]) } label: { Image(systemName: "forward.fill") }
                    }.buttonStyle(.borderless)
                }.frame(maxWidth: .infinity)
                Divider().frame(height: 240)
                VStack(spacing: 30) {
                    ControlSlider(title: "系统音量", icon: "speaker.wave.2.fill", value: $manager.volume) { manager.post("/remote/api/volume", body: ["value":manager.volume]) }
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Label("显示器亮度", systemImage: "sun.max.fill").font(.system(size: 14, weight: .semibold))
                            Spacer()
                            Text("检测到 \(manager.displays.count) 台").font(.caption).foregroundStyle(.secondary)
                        }
                        if manager.displays.isEmpty {
                            Text("正在读取显示器…").font(.callout).foregroundStyle(.secondary)
                        }
                        ForEach(manager.displays) { display in
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Image(systemName: display.id == 1 ? "laptopcomputer" : "display")
                                    Text(display.name).font(.system(size: 13, weight: .medium)).lineLimit(1)
                                    Spacer()
                                    if display.supported { Text("\(Int(display.brightness))%").font(.caption).foregroundStyle(.secondary).monospacedDigit() }
                                }
                                if display.supported {
                                    Slider(value: displayBinding(display.id), in: 0...100, onEditingChanged: { if !$0 { manager.setBrightness(id: display.id) } }).tint(.blue)
                                } else {
                                    Text("此连接方式不支持亮度控制").font(.caption).foregroundStyle(.orange)
                                }
                                if display.method == "ddc" {
                                    HStack(spacing: 10) {
                                        Button { manager.setDisplayPower(id: display.id, action: "wake") } label: { Label("唤醒外接屏", systemImage: "sunrise.fill") }
                                        Button { manager.setDisplayPower(id: display.id, action: "off") } label: { Label("完全息屏", systemImage: "power") }
                                    }.buttonStyle(.bordered).controlSize(.small)
                                }
                            }
                        }
                    }
                    Button("在浏览器预览遥控器") { manager.openRemote() }.buttonStyle(.bordered)
                }.frame(maxWidth: .infinity)
            }
        }.panel()
    }

    var mailPanel: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack { Label("邮件发送", systemImage: "envelope").font(.title2.bold()); Spacer(); Text(manager.configured ? "● 已配置" : "○ 等待配置").foregroundStyle(manager.configured ? .green : .orange) }
            Divider()
            HStack(alignment: .top, spacing: 28) {
                VStack(alignment: .leading, spacing: 16) {
                    Text("发件地址").font(.caption).foregroundStyle(.secondary)
                    Text(manager.mailDomain.isEmpty ? "请先配置发件域名" : "no-reply@\(manager.mailDomain)").font(.system(size: 18, weight: .semibold, design: .rounded))
                    Text(manager.configured ? "Resend 已连接，可以发件。" : "打开写信台后，在设置中粘贴 Resend 密钥。 ").font(.callout).foregroundStyle(.secondary)
                    Button("打开写信台") { manager.openMail() }.buttonStyle(.borderedProminent).controlSize(.large)
                }.frame(maxWidth: .infinity, alignment: .leading)
                Divider().frame(height: 220)
                VStack(alignment: .leading, spacing: 0) {
                    Text("最近发送").font(.headline).padding(.bottom, 8)
                    if manager.recent.isEmpty { Text("还没有发送记录").foregroundStyle(.secondary).padding(.top, 24) }
                    ForEach(Array(manager.recent.enumerated()), id: \.offset) { _, item in
                        let payload = item["payload"] as? [String: Any]
                        HStack { VStack(alignment: .leading, spacing: 3) { Text(payload?["subject"] as? String ?? "无主题").lineLimit(1); Text(((payload?["to"] as? [String])?.first) ?? "").font(.caption).foregroundStyle(.secondary).lineLimit(1) }; Spacer(); Text(statusName(item["status"] as? String ?? "sent")).font(.caption).foregroundStyle(.secondary) }.padding(.vertical, 10); Divider()
                    }
                }.frame(maxWidth: .infinity, alignment: .leading)
            }
        }.panel()
    }

    var statusRail: some View {
        HStack {
            statusItem("clock", "服务已连续运行", manager.uptime); Divider().frame(height: 42)
            statusItem("wifi", "局域网服务", manager.running ? "在线" : "离线"); Divider().frame(height: 42)
            statusItem("envelope", "最近邮件", "\(manager.recent.count) 封")
        }.padding(.vertical, 14).panel()
    }

    func infoRow(_ label: String, _ value: String, airDrop: Bool = false, copy: @escaping () -> Void) -> some View {
        HStack { VStack(alignment: .leading, spacing: 4) { Text(label).font(.caption).foregroundStyle(.secondary); Text(value).font(.system(size: 13, design: .monospaced)).lineLimit(1).textSelection(.enabled) }; Spacer(); if airDrop { Button { manager.airDrop(value) } label: { Label("AirDrop", systemImage: "airplayaudio") }.buttonStyle(.bordered) }; Button("复制", action: copy).buttonStyle(.bordered) }
    }
    func displayBinding(_ id: Int) -> Binding<Double> {
        Binding(get: { manager.displays.first(where: { $0.id == id })?.brightness ?? 0 }, set: { newValue in
            if let index = manager.displays.firstIndex(where: { $0.id == id }) { manager.displays[index].brightness = newValue }
        })
    }
    func statusItem(_ icon: String, _ label: String, _ value: String) -> some View { HStack(spacing: 12) { Image(systemName: icon).font(.title2); VStack(alignment: .leading) { Text(label).font(.caption).foregroundStyle(.secondary); Text(value).font(.headline) } }.frame(maxWidth: .infinity) }
    func statusName(_ s: String) -> String { ["delivered":"已投递","sent":"已发送","pending":"处理中","unconfirmed":"待确认","failed":"失败","bounced":"退信"][s] ?? s }
}

extension View {
    func panel() -> some View { self.padding(22).jasppGlass(radius: 25) }
}

@MainActor final class AppDelegate: NSObject, NSApplicationDelegate {
    var fanBridge: FanBridge?
    func applicationDidFinishLaunching(_ notification: Notification) {
        ServiceManager.shared.start()
        let fans = FanModel.shared
        fanBridge = FanBridge(handler: { request in fans.bridge(request) })
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }
    func applicationWillTerminate(_ notification: Notification) { FanModel.shared.restore(); ServiceManager.shared.stop(); fanBridge = nil }
}

@main
struct JasppApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject private var manager = ServiceManager.shared
    var body: some Scene {
        WindowGroup { MainView().preferredColorScheme(.light) }
            .defaultSize(width: 1100, height: 900)
            .windowStyle(.hiddenTitleBar)
        MenuBarExtra("Jaspp", systemImage: manager.running ? "dot.radiowaves.left.and.right" : "dot.radiowaves.left.and.right.slash") {
            Text(manager.running ? "Jaspp 正在运行" : "Jaspp 已停止")
            Button("显示 Jaspp") { NSApp.activate(ignoringOtherApps: true); NSApp.windows.first?.makeKeyAndOrderFront(nil) }
            Button("复制局域网地址") { manager.copy(manager.remoteURL) }
            Button("打开写信台") { manager.openMail() }
            Divider()
            Button("退出 Jaspp") { NSApp.terminate(nil) }
        }
    }
}
